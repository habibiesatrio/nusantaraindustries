import React, { useState } from 'react';
import { Commodity, KPIMetric } from '../types';
import { VALUE_CHAINS, IMPACT_COMPARISONS, INDUSTRIAL_ZONES } from '../services/mockData';
import CommodityCard from './CommodityCard';
import AIChatPanel from './AIChatPanel';
import HSCodeTable from './HSCodeTable';
import InvestmentCalculator from './InvestmentCalculator';
import ValueChainTree from './ValueChainTree';
import ComparisonSlider from './ComparisonSlider';
import IndustrialMap from './IndustrialMap';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import { ArrowUp, ArrowDown, Download, Filter, Calendar, Table, Calculator, GitMerge, ArrowLeftRight, Map } from 'lucide-react';

interface DashboardProps {
  metrics: KPIMetric[];
  commodities: Commodity[];
}

const Dashboard: React.FC<DashboardProps> = ({ metrics, commodities }) => {
  const [selectedCommodity, setSelectedCommodity] = useState<Commodity | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'map' | 'value-chain' | 'comparison' | 'hscode' | 'calculator'>('overview');

  // Consolidated data for the main chart
  const combinedData2023 = commodities.map(c => {
    const data2023 = c.data.find(d => d.year === 2023);
    return {
      name: c.name.split(' ')[0], // Short name
      raw: data2023?.rawExport || 0,
      processed: data2023?.processedExport || 0,
    };
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6 flex flex-col xl:flex-row justify-between items-start xl:items-end gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Data Tracking Real-time</h2>
          <p className="text-slate-400">Monitoring kinerja ekspor dan hilirisasi komoditas strategis.</p>
        </div>
        
        <div className="flex flex-wrap gap-2 bg-slate-900 p-1 rounded-lg border border-slate-800">
          <button 
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${activeTab === 'overview' ? 'bg-nusantara-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            Overview
          </button>
          <button 
            onClick={() => setActiveTab('map')}
            className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${activeTab === 'map' ? 'bg-nusantara-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            <Map size={16} />
            Peta Sebaran
          </button>
           <button 
            onClick={() => setActiveTab('value-chain')}
            className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${activeTab === 'value-chain' ? 'bg-nusantara-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            <GitMerge size={16} />
            Pohon Industri
          </button>
           <button 
            onClick={() => setActiveTab('comparison')}
            className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${activeTab === 'comparison' ? 'bg-nusantara-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            <ArrowLeftRight size={16} />
            Dampak Ekonomi
          </button>
          <button 
            onClick={() => setActiveTab('hscode')}
            className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${activeTab === 'hscode' ? 'bg-nusantara-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            <Table size={16} />
            HS Codes
          </button>
          <button 
            onClick={() => setActiveTab('calculator')}
            className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${activeTab === 'calculator' ? 'bg-nusantara-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            <Calculator size={16} />
            Kalkulator
          </button>
        </div>
      </div>

      {activeTab === 'overview' && (
        <>
          {/* KPI Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {metrics.map((kpi, idx) => (
              <div key={idx} className="bg-slate-900 border border-slate-800 p-5 rounded-xl hover:border-slate-700 transition-colors">
                <p className="text-slate-400 text-sm font-medium">{kpi.label}</p>
                <div className="flex items-end justify-between mt-2">
                  <h3 className="text-2xl font-bold text-white">{kpi.value}</h3>
                  <div className={`flex items-center gap-1 text-xs font-bold px-2 py-1 rounded ${
                    kpi.trend === 'up' ? 'text-green-400 bg-green-500/10' : 
                    kpi.trend === 'down' ? 'text-red-400 bg-red-500/10' : 'text-slate-400'
                  }`}>
                    {kpi.trend === 'up' ? <ArrowUp size={12} /> : kpi.trend === 'down' ? <ArrowDown size={12} /> : null}
                    {Math.abs(kpi.change)}%
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content (Left 2 Columns) */}
            <div className="lg:col-span-2 space-y-8">
              
              {/* Main Chart Section */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-lg font-bold text-white">Perbandingan Ekspor 2023</h2>
                    <p className="text-sm text-slate-400">Nilai Ekspor Mentah vs Hasil Hilirisasi (Juta USD)</p>
                  </div>
                  <div className="flex gap-2">
                    <button className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-lg border border-slate-700">
                      <Filter size={18} />
                    </button>
                    <button className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-lg border border-slate-700">
                      <Download size={18} />
                    </button>
                  </div>
                </div>
                
                <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={combinedData2023}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" />
                      <XAxis dataKey="name" stroke="#94a3b8" tick={{fontSize: 12}} />
                      <YAxis stroke="#94a3b8" tick={{fontSize: 12}} />
                      <Tooltip 
                        cursor={{fill: '#1e293b'}}
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }}
                      />
                      <Legend />
                      <Bar name="Ekspor Mentah" dataKey="raw" fill="#475569" radius={[4, 4, 0, 0]} />
                      <Bar name="Produk Hilir" dataKey="processed" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Detailed Breakdown / Commodity Grid */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold text-white">Komoditas Strategis</h2>
                  <div className="flex items-center gap-2 text-sm text-slate-400 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800">
                    <Calendar size={14} />
                    <span>Tahun Fiskal 2023-2024</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {commodities.map((comm) => (
                    <CommodityCard 
                      key={comm.id} 
                      data={comm} 
                      onClick={() => setSelectedCommodity(comm)}
                    />
                  ))}
                </div>
              </div>

              {/* Detail View for Selected Commodity (if any) */}
              {selectedCommodity && (
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 scroll-mt-6" id="detail-view">
                  <div className="flex justify-between items-start mb-6">
                    <div>
                       <h2 className="text-2xl font-bold text-white mb-2">{selectedCommodity.name}</h2>
                       <p className="text-slate-400 max-w-2xl">{selectedCommodity.description}</p>
                    </div>
                    <button 
                      onClick={() => setSelectedCommodity(null)}
                      className="text-sm text-slate-500 hover:text-white"
                    >
                      Tutup Detail
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                     <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
                        <p className="text-sm text-slate-500 mb-1">Total Cadangan</p>
                        <p className="text-lg font-semibold text-white">{selectedCommodity.reserves}</p>
                     </div>
                     <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
                        <p className="text-sm text-slate-500 mb-1">Wilayah Utama</p>
                        <p className="text-lg font-semibold text-white">{selectedCommodity.location.join(', ')}</p>
                     </div>
                     <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
                        <p className="text-sm text-slate-500 mb-1">Regulasi Kunci</p>
                        <ul className="list-disc list-inside text-sm text-nusantara-400">
                           {selectedCommodity.regulations.map((reg, i) => (
                             <li key={i} className="truncate">{reg}</li>
                           ))}
                        </ul>
                     </div>
                  </div>

                  <h3 className="text-md font-semibold text-white mb-4">Tren Pertumbuhan Smelter</h3>
                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                       <LineChart data={selectedCommodity.data}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" />
                          <XAxis dataKey="year" stroke="#94a3b8" />
                          <YAxis stroke="#94a3b8" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }}
                          />
                          <Line type="monotone" dataKey="smelterCount" stroke="#22d3ee" strokeWidth={3} dot={{r: 4, fill: '#22d3ee'}} activeDot={{r: 6}} />
                       </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

            </div>

            {/* Right Column: AI & Notifications */}
            <div className="lg:col-span-1 space-y-6">
               <div className="h-[600px] lg:sticky lg:top-24">
                 <AIChatPanel selectedCommodity={selectedCommodity} />
               </div>

               {/* Simple Activity Feed */}
               <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
                 <h3 className="text-white font-semibold mb-4 text-sm">Aktivitas Terkini (ERP Log)</h3>
                 <div className="space-y-4">
                   {[
                     { time: '10:42', text: 'Input data produksi PT Vale Indonesia', status: 'success' },
                     { time: '09:15', text: 'Update regulasi ekspor Bauxite', status: 'warning' },
                     { time: 'Yesterday', text: 'Sinkronisasi Database Bea Cukai', status: 'success' },
                   ].map((log, i) => (
                     <div key={i} className="flex gap-3 text-sm">
                        <div className="min-w-[50px] text-slate-500 text-xs mt-0.5">{log.time}</div>
                        <div>
                          <p className="text-slate-300">{log.text}</p>
                          <span className={`text-[10px] uppercase tracking-wide ${log.status === 'success' ? 'text-green-500' : 'text-amber-500'}`}>
                            {log.status}
                          </span>
                        </div>
                     </div>
                   ))}
                 </div>
               </div>
            </div>
          </div>
        </>
      )}

      {activeTab === 'map' && <IndustrialMap zones={INDUSTRIAL_ZONES} />}
      {activeTab === 'value-chain' && <ValueChainTree chains={VALUE_CHAINS} />}
      {activeTab === 'comparison' && <ComparisonSlider data={IMPACT_COMPARISONS} />}
      {activeTab === 'hscode' && <HSCodeTable commodities={commodities} />}
      {activeTab === 'calculator' && <InvestmentCalculator />}
    </div>
  );
};

export default Dashboard;