import React, { useState } from 'react';
import { Commodity } from '../types';
import { Search, FileSpreadsheet, Filter } from 'lucide-react';

interface HSCodeTableProps {
  commodities: Commodity[];
}

const HSCodeTable: React.FC<HSCodeTableProps> = ({ commodities }) => {
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'All' | 'Raw' | 'Processed'>('All');

  const allCodes = commodities.flatMap(c => c.hsCodes.map(hs => ({...hs, commodity: c.name})));
  
  const filtered = allCodes.filter(item => {
    const matchSearch = item.code.includes(search) || item.description.toLowerCase().includes(search.toLowerCase());
    const matchType = filterType === 'All' || item.category === filterType;
    return matchSearch && matchType;
  });

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
      <div className="p-6 border-b border-slate-800 flex flex-col md:flex-row justify-between gap-4">
        <div>
           <h3 className="text-lg font-bold text-white">Klasifikasi HS Code & Tarif</h3>
           <p className="text-sm text-slate-400">Database kode harmonisasi bea cukai untuk komoditas strategis.</p>
        </div>
        <div className="flex gap-2">
           <div className="relative">
             <Search className="absolute left-3 top-2.5 text-slate-500 w-4 h-4" />
             <input 
               type="text" 
               placeholder="Cari Kode / Deskripsi..."
               value={search}
               onChange={(e) => setSearch(e.target.value)}
               className="bg-slate-950 border border-slate-700 text-white pl-9 pr-4 py-2 rounded-lg text-sm focus:border-nusantara-500 outline-none w-full md:w-64"
             />
           </div>
           <select 
             value={filterType}
             onChange={(e) => setFilterType(e.target.value as any)}
             className="bg-slate-950 border border-slate-700 text-white px-3 py-2 rounded-lg text-sm outline-none"
           >
             <option value="All">Semua Tipe</option>
             <option value="Raw">Mentah (Raw)</option>
             <option value="Processed">Hilir (Processed)</option>
           </select>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm text-slate-400">
          <thead className="bg-slate-950 text-slate-200 uppercase font-medium">
            <tr>
              <th className="px-6 py-4">HS Code</th>
              <th className="px-6 py-4">Deskripsi</th>
              <th className="px-6 py-4">Komoditas</th>
              <th className="px-6 py-4">Kategori</th>
              <th className="px-6 py-4 text-right">Bea Keluar</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {filtered.map((item, idx) => (
              <tr key={idx} className="hover:bg-slate-800/50 transition-colors">
                <td className="px-6 py-4 font-mono text-nusantara-400 font-medium">{item.code}</td>
                <td className="px-6 py-4 text-white">{item.description}</td>
                <td className="px-6 py-4">{item.commodity}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                    item.category === 'Raw' 
                      ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' 
                      : 'bg-green-500/10 text-green-400 border border-green-500/20'
                  }`}>
                    {item.category}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  {item.tariff > 0 ? (
                    <span className="text-red-400">{item.tariff}%</span>
                  ) : (
                    <span className="text-slate-500">-</span>
                  )}
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-slate-500">
                  Tidak ada data ditemukan.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-between items-center text-xs text-slate-500">
        <div className="flex items-center gap-2">
          <FileSpreadsheet size={14} />
          <span>Sumber: Buku Tarif Kepabeanan Indonesia (BTKI) 2023</span>
        </div>
        <span>Total: {filtered.length} Records</span>
      </div>
    </div>
  );
};

export default HSCodeTable;