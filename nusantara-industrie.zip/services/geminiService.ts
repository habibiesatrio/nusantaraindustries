import { GoogleGenAI } from "@google/genai";
import { COMMODITIES } from "./mockData";

// Initialize Gemini
// Note: In a production PHP env, this might be a backend proxy. 
// Here we use the frontend SDK with the user's API key.
const apiKey = process.env.API_KEY || ''; 
const ai = new GoogleGenAI({ apiKey });

export const generateIndustryInsight = async (query: string, contextId?: string): Promise<string> => {
  if (!apiKey) {
    return "API Key is missing. Please configure process.env.API_KEY.";
  }

  try {
    let systemPrompt = `
      Anda adalah "Nusantara AI", analis industri senior untuk Pemerintah Indonesia dan Investor Asing.
      Tugas anda adalah memberikan wawasan mendalam tentang hilirisasi industri.
      Gunakan data berikut sebagai konteks jika relevan:
      ${JSON.stringify(COMMODITIES.map(c => ({ name: c.name, desc: c.description, data: c.data })))}
      
      Gaya bicara: Profesional, berbasis data, ringkas, dan strategis.
      Fokus pada dampak ekonomi, regulasi, dan prediksi masa depan.
      Jangan berhalusinasi data. Gunakan data yang diberikan di atas.
    `;

    if (contextId) {
      const specific = COMMODITIES.find(c => c.id === contextId);
      if (specific) {
        systemPrompt += `\nFokus analisis pada komoditas: ${specific.name}. Cadangan: ${specific.reserves}. Lokasi Utama: ${specific.location.join(', ')}.`;
      }
    }

    const model = 'gemini-3-flash-preview';
    
    const response = await ai.models.generateContent({
      model: model,
      contents: [
        { role: 'user', parts: [{ text: query }] }
      ],
      config: {
        systemInstruction: systemPrompt,
        thinkingConfig: { thinkingBudget: 0 } // Fast response for chat
      }
    });

    return response.text || "Maaf, saya tidak dapat menghasilkan analisis saat ini.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Terjadi kesalahan saat menghubungkan ke pusat data AI.";
  }
};