import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import EconomicOverview from './components/EconomicOverview';
import Dashboard from './components/Dashboard';
import AuthModal from './components/AuthModal';
import Footer from './components/Footer';
import ERPPanel from './components/ERPPanel';
import KnowledgeHub from './components/KnowledgeHub';
import { KPI_METRICS, COMMODITIES, LIBRARY_RESOURCES, GLOSSARY_TERMS } from './services/mockData';
import { User, KPIMetric, LibraryResource, GlossaryTerm } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState('home');
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  
  // "Database" State for ERP System
  const [liveMetrics, setLiveMetrics] = useState<KPIMetric[]>(KPI_METRICS);
  const [libraryItems, setLibraryItems] = useState<LibraryResource[]>(LIBRARY_RESOURCES);
  const [glossaryItems, setGlossaryItems] = useState<GlossaryTerm[]>(GLOSSARY_TERMS);

  const navigateTo = (view: string) => {
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    // Redirect all logged-in users to tracking view so they see the dashboard/panel immediately
    navigateTo('tracking');
  };

  const handleLogout = () => {
    setUser(null);
    navigateTo('home');
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-200 flex flex-col">
      <Header 
        currentView={currentView} 
        onNavigate={navigateTo} 
        onOpenAuth={() => setIsAuthOpen(true)}
        user={user}
        onLogout={handleLogout}
      />
      
      <main className="flex-1">
        {currentView === 'home' && (
          <>
            <Hero onStartTracking={() => navigateTo('tracking')} />
            <EconomicOverview metrics={liveMetrics} />
          </>
        )}
        
        {currentView === 'tracking' && (
          <div className="container mx-auto px-4 py-8 animate-fadeIn">
            {/* Show ERP Panel only for Admins */}
            {user?.role === 'admin' && (
              <ERPPanel 
                metrics={liveMetrics} 
                onUpdateMetrics={setLiveMetrics}
                libraryItems={libraryItems}
                onUpdateLibrary={setLibraryItems}
                glossaryItems={glossaryItems}
                onUpdateGlossary={setGlossaryItems}
              />
            )}

            {/* Welcome message for non-admins */}
            {user && user.role !== 'admin' && (
               <div className="mb-6 p-4 bg-nusantara-900/20 border border-nusantara-500/30 rounded-xl">
                 <h2 className="text-xl font-bold text-white">Selamat Datang, {user.name}</h2>
                 <p className="text-slate-400 text-sm">Anda mengakses data tracking sebagai Investor.</p>
               </div>
            )}
            
            <Dashboard 
              metrics={liveMetrics} 
              commodities={COMMODITIES}
            />
          </div>
        )}

        {currentView === 'knowledge' && (
          <KnowledgeHub 
            libraryItems={libraryItems}
            glossaryItems={glossaryItems}
          />
        )}
      </main>
      
      <Footer />

      <AuthModal 
        isOpen={isAuthOpen} 
        onClose={() => setIsAuthOpen(false)} 
        onLogin={handleLogin}
      />
    </div>
  );
};

export default App;