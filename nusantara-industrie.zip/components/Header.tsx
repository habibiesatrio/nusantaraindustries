import React from 'react';
import { Factory, Menu, User as UserIcon, LogOut, Settings } from 'lucide-react';
import { User } from '../types';

interface HeaderProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenAuth: () => void;
  user: User | null;
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, onNavigate, onOpenAuth, user, onLogout }) => {
  return (
    <header className="sticky top-0 z-50 w-full bg-slate-900/90 backdrop-blur border-b border-slate-800">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <div 
          className="flex items-center gap-3 cursor-pointer" 
          onClick={() => onNavigate('home')}
        >
          <div className="w-8 h-8 bg-nusantara-600 rounded-lg flex items-center justify-center">
            <Factory className="text-white w-5 h-5" />
          </div>
          <div>
            <h1 className="text-white font-bold text-lg leading-none">Nusantara</h1>
            <span className="text-nusantara-400 text-xs font-medium tracking-wider">INDUSTRIE</span>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <button 
            onClick={() => onNavigate('home')}
            className={`text-sm font-medium transition-colors ${currentView === 'home' ? 'text-nusantara-400' : 'text-slate-300 hover:text-white'}`}
          >
            Beranda
          </button>
          <button 
            onClick={() => onNavigate('tracking')}
            className={`text-sm font-medium transition-colors ${currentView === 'tracking' ? 'text-nusantara-400' : 'text-slate-300 hover:text-white'}`}
          >
            Data Tracking
          </button>
          <button 
             onClick={() => onNavigate('knowledge')}
             className={`text-sm font-medium transition-colors ${currentView === 'knowledge' ? 'text-nusantara-400' : 'text-slate-300 hover:text-white'}`}
          >
            Tentang Hilirisasi
          </button>
        </nav>

        {/* Auth / Mobile Menu */}
        <div className="flex items-center gap-4">
          {user ? (
            <div className="hidden md:flex items-center gap-4">
               <div className="text-right hidden lg:block">
                 <p className="text-sm text-white font-medium">{user.name}</p>
                 <p className="text-xs text-slate-400 uppercase">{user.role}</p>
               </div>
               {user.role === 'admin' && (
                 <button 
                    onClick={() => onNavigate('tracking')} 
                    className="p-2 text-slate-400 hover:text-amber-500 transition-colors" 
                    title="ERP Admin Panel"
                 >
                   <Settings size={20} />
                 </button>
               )}
               <button 
                 onClick={onLogout}
                 className="p-2 text-slate-400 hover:text-red-400 transition-colors"
               >
                 <LogOut size={20} />
               </button>
            </div>
          ) : (
            <button 
              onClick={onOpenAuth}
              className="hidden md:flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-sm font-medium rounded-lg border border-slate-700 transition-all"
            >
              <UserIcon size={16} />
              Portal Login
            </button>
          )}
          
          <button className="md:hidden text-white p-2">
            <Menu size={24} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;