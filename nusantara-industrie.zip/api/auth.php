<?php
session_start(); // Start PHP Session
require_once 'config.php';

$data = json_decode(file_get_contents("php://input"));

// Helper function for JSON response
function send_json($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data);
    exit();
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

// Check Session Status (Frontend check)
if ($action == 'check_session') {
    if (isset($_SESSION['user_id'])) {
        send_json([
            "isAuthenticated" => true,
            "user" => [
                "id" => $_SESSION['user_id'],
                "name" => $_SESSION['user_name'],
                "email" => $_SESSION['user_email'],
                "role" => $_SESSION['user_role']
            ]
        ]);
    } else {
        send_json(["isAuthenticated" => false], 401);
    }
}

if (!$data) {
    // If no input data and action is not check_session, return error
    if ($action !== 'logout') {
        send_json(["message" => "Invalid input"], 400);
    }
}

if ($action == 'register') {
    // Input Validation
    if (empty($data->name) || empty($data->email) || empty($data->password)) {
        send_json(["message" => "Incomplete data"], 400);
    }

    $name = htmlspecialchars(strip_tags($data->name));
    $email = htmlspecialchars(strip_tags($data->email));
    
    // Secure Hash
    $password = password_hash($data->password, PASSWORD_BCRYPT);
    
    // Determine Role
    $role = (strpos($email, 'nusantaraindustrie.com') !== false || strpos($email, 'kemenperin.go.id') !== false) ? 'admin' : 'investor';

    try {
        $query = "INSERT INTO users (name, email, password, role) VALUES (:name, :email, :password, :role)";
        $stmt = $conn->prepare($query);
        
        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":password", $password);
        $stmt->bindParam(":role", $role);

        if ($stmt->execute()) {
            send_json([
                "message" => "User created successfully",
                "user" => [
                    "name" => $name,
                    "email" => $email,
                    "role" => $role
                ]
            ]);
        }
    } catch (PDOException $e) {
        send_json(["message" => "Email already exists or database error."], 500);
    }

} elseif ($action == 'login') {
    $email = htmlspecialchars(strip_tags($data->email));
    $password = $data->password;

    try {
        $query = "SELECT id, name, email, password, role FROM users WHERE email = :email LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(":email", $email);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Verify Password Hash
            if (password_verify($password, $row['password'])) {
                
                // Set Session
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['user_name'] = $row['name'];
                $_SESSION['user_email'] = $row['email'];
                $_SESSION['user_role'] = $row['role'];

                // Remove password from response
                unset($row['password']);
                
                send_json([
                    "message" => "Login successful",
                    "user" => $row,
                    "session_id" => session_id()
                ]);
            } else {
                send_json(["message" => "Invalid password"], 401);
            }
        } else {
            send_json(["message" => "User not found"], 404);
        }
    } catch (PDOException $e) {
        send_json(["message" => "Database error"], 500);
    }

} elseif ($action == 'logout') {
    session_unset();
    session_destroy();
    send_json(["message" => "Logged out successfully"]);

} else {
    send_json(["message" => "Invalid action"], 400);
}
?>