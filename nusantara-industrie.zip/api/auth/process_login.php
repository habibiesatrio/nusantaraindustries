<?php
session_start();
require_once '../config/db.php';

header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"));

if (!$data || !isset($data->email) || !isset($data->password)) {
    http_response_code(400);
    echo json_encode(["message" => "Data tidak lengkap."]);
    exit();
}

$email = htmlspecialchars(strip_tags($data->email));
$password = $data->password;

try {
    $query = "SELECT id, name, email, password, role FROM users WHERE email = :email LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":email", $email);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Verifikasi Password
        if (password_verify($password, $row['password'])) {
            // Set Session PHP
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_name'] = $row['name'];
            $_SESSION['user_email'] = $row['email'];
            $_SESSION['user_role'] = $row['role'];
            $_SESSION['login_time'] = time();

            // Hapus password dari respons JSON
            unset($row['password']);
            
            echo json_encode([
                "status" => "success",
                "message" => "Login berhasil.",
                "user" => $row,
                "session_id" => session_id()
            ]);
        } else {
            http_response_code(401);
            echo json_encode(["status" => "error", "message" => "Password salah."]);
        }
    } else {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "User tidak ditemukan."]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database error: " . $e->getMessage()]);
}
?>