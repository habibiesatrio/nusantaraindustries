<?php
session_start();
require_once '../config/db.php';

header("Content-Type: application/json");

// Keamanan: Cek apakah user sudah login DAN role-nya admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(["status" => "forbidden", "message" => "Akses ditolak. Hanya Admin yang diperbolehkan."]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if (!$data) {
    http_response_code(400);
    echo json_encode(["message" => "Invalid Input"]);
    exit();
}

// Logika Update (Contoh: Update data komoditas atau metrics)
// Disini kita mensimulasikan update sukses karena struktur tabel metrics dinamis (JSON di frontend)
// Pada implementasi nyata, Anda akan melakukan loop update ke tabel `commodity_data` atau tabel metrics terkait.

try {
    // Simulasi query update log aktivitas admin
    // $stmt = $conn->prepare("INSERT INTO admin_logs (user_id, action, timestamp) VALUES (:uid, 'update_data', NOW())");
    // $stmt->execute([':uid' => $_SESSION['user_id']]);

    echo json_encode([
        "status" => "success",
        "message" => "Data berhasil diperbarui di sistem ERP.",
        "updated_at" => date("Y-m-d H:i:s"),
        "admin" => $_SESSION['user_name']
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Gagal update database."]);
}
?>