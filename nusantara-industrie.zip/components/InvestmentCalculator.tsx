import React, { useState } from 'react';
import { Calculator, DollarSign, Users, Briefcase, TrendingUp, RefreshCw, ArrowRight } from 'lucide-react';
import { CommodityType } from '../types';
import { CALCULATOR_RATIOS } from '../services/mockData';

const InvestmentCalculator: React.FC = () => {
  const [volume, setVolume] = useState<number>(1000); // in Tons
  const [selectedCommodityId, setSelectedCommodityId] = useState<string>('nickel-01');
  
  const ratioData = CALCULATOR_RATIOS.find(r => r.commodityId === selectedCommodityId) || CALCULATOR_RATIOS[0];

  const rawValue = volume * ratioData.rawPrice;
  const processedValue = volume * ratioData.processedPrice;
  const valueAdded = processedValue - rawValue;
  const valueMultiplier = (processedValue / rawValue).toFixed(1);
  
  const estimatedJobs = Math.round((volume / 1000) * ratioData.jobMultiplier);
  const potentialTax = processedValue * ratioData.taxRate;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
      <div className="flex items-center gap-2 mb-6">
        <Calculator className="text-nusantara-400" />
        <div>
          <h3 className="text-lg font-bold text-white">Kalkulator Nilai Tambah (Multiplier Effect)</h3>
          <p className="text-sm text-slate-400">Simulasi dampak ekonomi dari hilirisasi bahan mentah.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        {/* Input Section */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <label className="block text-sm font-medium text-slate-300 mb-2">Pilih Komoditas</label>
            <div className="flex flex-wrap gap-2 mb-4">
              {CALCULATOR_RATIOS.map(r => (
                <button
                  key={r.commodityId}
                  onClick={() => setSelectedCommodityId(r.commodityId)}
                  className={`px-3 py-1.5 text-xs rounded-lg border transition-all ${
                    selectedCommodityId === r.commodityId 
                      ? 'bg-nusantara-600 text-white border-nusantara-500' 
                      : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-white'
                  }`}
                >
                  {r.productName}
                </button>
              ))}
            </div>

            <label className="block text-sm font-medium text-slate-300 mb-2">Volume Input Mentah (Ton)</label>
            <div className="relative mb-2">
              <input 
                type="number"
                min="0"
                step="100"
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-4 py-3 focus:border-nusantara-500 outline-none font-mono text-lg"
              />
              <div className="absolute right-4 top-3.5 text-slate-500 text-sm">Ton</div>
            </div>
            <input 
              type="range" 
              min="100" 
              max="100000" 
              step="100"
              value={volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-nusantara-500"
            />
          </div>

          <div className="p-4 bg-blue-900/10 border border-blue-500/20 rounded-lg">
             <div className="flex justify-between items-center text-sm mb-2">
                <span className="text-blue-300">Rasio Nilai Tambah</span>
                <span className="font-bold text-white text-lg">{valueMultiplier}x Lipat</span>
             </div>
             <p className="text-xs text-blue-400">
               Dengan mengolah {volume.toLocaleString()} ton bijih menjadi {ratioData.productName}, nilai ekonomi melonjak signifikan.
             </p>
          </div>
        </div>

        {/* Output Section */}
        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-4">
           {/* Card 1: Revenue Comparison */}
           <div className="col-span-1 md:col-span-2 bg-slate-950 p-5 rounded-xl border border-slate-800 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10"><DollarSign size={64} /></div>
              <h4 className="text-slate-400 text-sm mb-4">Perbandingan Nilai Jual</h4>
              <div className="flex items-center gap-4">
                 <div className="flex-1">
                    <p className="text-xs text-slate-500 mb-1">Jual Mentah</p>
                    <p className="text-xl font-bold text-slate-400">${rawValue.toLocaleString()}</p>
                 </div>
                 <ArrowRight className="text-nusantara-500" />
                 <div className="flex-1">
                    <p className="text-xs text-nusantara-400 mb-1 font-bold">Jual Produk Hilir</p>
                    <p className="text-2xl font-bold text-white">${processedValue.toLocaleString()}</p>
                 </div>
              </div>
              <div className="mt-4 pt-4 border-t border-slate-800 flex justify-between items-center">
                 <span className="text-sm text-green-400">Keuntungan Tambahan (Surplus)</span>
                 <span className="text-lg font-bold text-green-400">+${valueAdded.toLocaleString()}</span>
              </div>
           </div>

           {/* Card 2: Jobs */}
           <div className="bg-slate-950 p-5 rounded-xl border border-slate-800">
              <div className="flex items-center gap-3 mb-2">
                 <div className="p-2 bg-purple-500/10 rounded-lg text-purple-400"><Users size={18} /></div>
                 <h4 className="text-slate-300 font-medium">Lapangan Kerja</h4>
              </div>
              <p className="text-2xl font-bold text-white mt-2">+{estimatedJobs.toLocaleString()}</p>
              <p className="text-xs text-slate-500 mt-1">Potensi tenaga kerja terserap</p>
           </div>

           {/* Card 3: Tax Revenue */}
           <div className="bg-slate-950 p-5 rounded-xl border border-slate-800">
              <div className="flex items-center gap-3 mb-2">
                 <div className="p-2 bg-amber-500/10 rounded-lg text-amber-400"><Briefcase size={18} /></div>
                 <h4 className="text-slate-300 font-medium">Potensi Pajak</h4>
              </div>
              <p className="text-2xl font-bold text-white mt-2">${potentialTax.toLocaleString()}</p>
              <p className="text-xs text-slate-500 mt-1">Estimasi pendapatan negara (Royalti/PPh)</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default InvestmentCalculator;