import React, { useState } from 'react';
import { IndustrialZone } from '../types';
import { MapPin, Users, Factory, AlertCircle } from 'lucide-react';

interface IndustrialMapProps {
  zones: IndustrialZone[];
}

const IndustrialMap: React.FC<IndustrialMapProps> = ({ zones }) => {
  const [activeZone, setActiveZone] = useState<IndustrialZone | null>(null);

  // Simple SVG Path approximations for Indonesia
  const paths = {
    sumatra: "M 10 20 L 40 10 L 80 50 L 60 80 L 20 60 Z", 
    java: "M 65 90 L 130 90 L 140 100 L 60 100 Z",
    kalimantan: "M 90 40 L 130 35 L 140 70 L 100 80 Z",
    sulawesi: "M 150 50 L 170 40 L 160 70 L 180 60 L 160 80 Z",
    papua: "M 230 50 L 280 40 L 290 70 L 240 80 Z"
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden relative">
      <div className="p-6 border-b border-slate-800">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          <MapPin className="text-nusantara-500" />
          Peta Sebaran Smelter & Kawasan Industri
        </h3>
        <p className="text-sm text-slate-400">Lokasi Proyek Strategis Nasional (PSN) Hilirisasi.</p>
      </div>

      <div className="relative bg-slate-950 p-4 h-[400px] w-full flex items-center justify-center overflow-hidden">
        {/* Background Grid */}
        <div className="absolute inset-0 opacity-10" 
             style={{ backgroundImage: 'radial-gradient(#334155 1px, transparent 1px)', backgroundSize: '20px 20px' }}>
        </div>

        {/* Abstract Indonesia Map */}
        {/* Note: This is a highly stylized abstract map representation for code simplicity */}
        <svg viewBox="0 0 300 120" className="w-full h-full drop-shadow-[0_0_15px_rgba(14,165,233,0.3)]">
           {/* Sumatra */}
           <path d="M 20 25 L 50 15 L 65 55 L 40 70 Z" fill="#1e293b" stroke="#475569" strokeWidth="0.5" />
           {/* Java */}
           <path d="M 55 75 L 110 80 L 105 88 L 50 85 Z" fill="#1e293b" stroke="#475569" strokeWidth="0.5" />
           {/* Kalimantan */}
           <path d="M 75 30 L 115 25 L 120 55 L 85 60 Z" fill="#1e293b" stroke="#475569" strokeWidth="0.5" />
           {/* Sulawesi */}
           <path d="M 125 35 L 145 35 L 135 55 L 150 50 L 140 70 Z" fill="#1e293b" stroke="#475569" strokeWidth="0.5" />
           {/* Papua */}
           <path d="M 190 40 L 230 35 L 235 60 L 200 65 Z" fill="#1e293b" stroke="#475569" strokeWidth="0.5" />
           
           {/* Halmahera / Maluku */}
           <path d="M 160 30 L 170 30 L 165 45 Z" fill="#1e293b" stroke="#475569" strokeWidth="0.5" />
        </svg>

        {/* Zone Markers */}
        {zones.map((zone) => (
          <div
            key={zone.id}
            className="absolute cursor-pointer group"
            style={{ 
              left: `${zone.coordinates.x}%`, 
              top: `${zone.coordinates.y}%` 
            }}
            onMouseEnter={() => setActiveZone(zone)}
            onMouseLeave={() => setActiveZone(null)}
          >
            <div className={`relative flex items-center justify-center w-4 h-4 rounded-full transition-all duration-300 ${
              activeZone?.id === zone.id ? 'scale-150' : ''
            }`}>
              <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping ${
                zone.status === 'Beroperasi' ? 'bg-green-500' : 'bg-amber-500'
              }`}></span>
              <span className={`relative inline-flex rounded-full h-3 w-3 ${
                zone.status === 'Beroperasi' ? 'bg-green-500' : 'bg-amber-500'
              }`}></span>
            </div>
            
            {/* Label (Always Visible on Desktop, slightly offset) */}
            <div className="absolute left-6 top-1/2 -translate-y-1/2 hidden md:block w-32 pointer-events-none">
               <span className="text-[10px] font-bold text-slate-400 bg-slate-900/80 px-1 rounded whitespace-nowrap">
                 {zone.name.split(' ')[0]}
               </span>
            </div>
          </div>
        ))}

        {/* Floating Tooltip */}
        {activeZone && (
          <div className="absolute bottom-4 left-4 right-4 md:right-auto md:left-4 md:bottom-4 bg-slate-900/95 border border-nusantara-500/50 p-4 rounded-xl shadow-2xl backdrop-blur-md animate-fadeIn z-20 max-w-sm">
            <div className="flex justify-between items-start mb-2">
              <h4 className="text-white font-bold">{activeZone.name}</h4>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                activeZone.status === 'Beroperasi' ? 'bg-green-500/20 text-green-400' : 'bg-amber-500/20 text-amber-400'
              }`}>
                {activeZone.status}
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-3 flex items-center gap-1">
              <MapPin size={12} /> {activeZone.location}
            </p>
            
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-800 p-2 rounded-lg">
                <div className="flex items-center gap-1 text-slate-500 mb-1">
                  <Factory size={12} />
                  <span>Kapasitas</span>
                </div>
                <span className="text-white font-semibold">{activeZone.capacity}</span>
              </div>
              <div className="bg-slate-800 p-2 rounded-lg">
                <div className="flex items-center gap-1 text-slate-500 mb-1">
                  <Users size={12} />
                  <span>Tenaga Kerja</span>
                </div>
                <span className="text-white font-semibold">{activeZone.jobs.toLocaleString()} Org</span>
              </div>
            </div>
          </div>
        )}
      </div>
      
      <div className="p-4 bg-slate-950 border-t border-slate-800 flex gap-4 text-xs text-slate-500 justify-center">
        <div className="flex items-center gap-2">
           <span className="w-2 h-2 rounded-full bg-green-500"></span>
           Beroperasi
        </div>
        <div className="flex items-center gap-2">
           <span className="w-2 h-2 rounded-full bg-amber-500"></span>
           Tahap Konstruksi
        </div>
      </div>
    </div>
  );
};

export default IndustrialMap;