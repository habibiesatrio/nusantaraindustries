import React, { useState } from 'react';
import { GlossaryTerm } from '../types';
import { BookA, Search } from 'lucide-react';

interface GlossaryProps {
  data: GlossaryTerm[];
}

const Glossary: React.FC<GlossaryProps> = ({ data }) => {
  const [search, setSearch] = useState('');

  const filteredTerms = data.filter(item => 
    item.term.toLowerCase().includes(search.toLowerCase()) || 
    item.definition.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-6">
         <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-500/10 rounded-xl text-amber-500">
               <BookA size={24} />
            </div>
            <div>
               <h3 className="text-2xl font-bold text-white">Kamus Industri</h3>
               <p className="text-slate-400 text-sm">Istilah teknis dan singkatan dalam dunia hilirisasi.</p>
            </div>
         </div>

         <div className="relative w-full md:w-80">
            <Search className="absolute left-4 top-3.5 text-slate-500 w-4 h-4" />
            <input 
              type="text" 
              placeholder="Cari istilah (Contoh: Smelter, TKDN)..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-white pl-10 pr-4 py-3 rounded-xl text-sm focus:border-amber-500 outline-none shadow-inner"
            />
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredTerms.map((item) => (
          <div key={item.id} className="bg-slate-950/50 border border-slate-800 p-5 rounded-xl hover:border-amber-500/30 transition-all hover:bg-slate-900 group">
             <div className="flex justify-between items-start mb-2">
                <h4 className="text-lg font-bold text-white group-hover:text-amber-500 transition-colors">{item.term}</h4>
                <span className="text-[10px] uppercase font-bold text-slate-500 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                  {item.category}
                </span>
             </div>
             <p className="text-sm text-slate-400 leading-relaxed">
               {item.definition}
             </p>
          </div>
        ))}

        {filteredTerms.length === 0 && (
           <div className="col-span-full py-12 text-center">
              <p className="text-slate-500">Istilah tidak ditemukan.</p>
           </div>
        )}
      </div>
    </div>
  );
};

export default Glossary;