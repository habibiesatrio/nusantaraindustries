import { Commodity, CommodityType, KPIMetric, MarketShare, PSNStatus, ValueChain, ImpactComparison, IndustrialZone, ValueAddedRatio, PolicyLog, LibraryResource, GlossaryTerm } from '../types';

export const KPI_METRICS: KPIMetric[] = [
  { id: 'kpi-1', label: 'Total Nilai Ekspor Hilirisasi', value: '$34.2B', change: 12.5, trend: 'up' },
  { id: 'kpi-2', label: 'Investasi Smelter Baru', value: '$4.1B', change: 8.2, trend: 'up' },
  { id: 'kpi-3', label: 'Penyerapan Tenaga Kerja', value: '145.000', change: 5.4, trend: 'up' },
  { id: 'kpi-4', label: 'Volume Ekspor Mentah', value: '2.1M Ton', change: -15.3, trend: 'down' },
];

export const GLOBAL_MARKET_SHARE: MarketShare[] = [
  { country: 'Indonesia', share: 55, fill: '#0ea5e9' }, // Nusantara-500
  { country: 'Filipina', share: 15, fill: '#475569' },
  { country: 'Rusia', share: 10, fill: '#64748b' },
  { country: 'Kaledonia Baru', share: 8, fill: '#94a3b8' },
  { country: 'Lainnya', share: 12, fill: '#cbd5e1' },
];

export const PSN_STATUS: PSNStatus[] = [
  { status: 'Beroperasi', count: 45, color: '#22c55e' }, // Green
  { status: 'Konstruksi', count: 35, color: '#0ea5e9' }, // Blue
  { status: 'Perencanaan', count: 15, color: '#f59e0b' }, // Amber
  { status: 'Ditunda/Batal', count: 5, color: '#ef4444' }, // Red
];

// ... (Existing Commodities data retained, just importing new data below)
export const COMMODITIES: Commodity[] = [
  {
    id: 'nickel-01',
    name: 'Nikel (Nickel)',
    type: CommodityType.NICKEL,
    reserves: '21 Juta Ton (Terbesar di Dunia)',
    description: 'Komoditas utama baterai EV. Larangan ekspor bijih nikel sejak 2020 telah memicu lonjakan investasi smelter.',
    location: ['Sulawesi Tengah', 'Sulawesi Tenggara', 'Maluku Utara'],
    regulations: ['Permen ESDM No. 11/2019', 'UU Minerba No. 3/2020'],
    hsCodes: [
      { code: '2604.00.00', description: 'Bijih Nikel & Konsentrat', category: 'Raw', tariff: 0 },
      { code: '7501.10.00', description: 'Nickel Mattes', category: 'Processed', tariff: 0 },
      { code: '7202.60.00', description: 'Ferronickel (FeNi)', category: 'Processed', tariff: 0 }
    ],
    spotlight: {
      headline: "Hilirisasi Nikel: Mengubah Tanah Air Menjadi Nilai Tambah",
      subHeadline: "Indonesia sebagai Produsen No.1 Dunia dengan 34 Smelter Aktif.",
      metrics: {
        valueCreation: "34x",
        jobCreation: "120.000+",
        revenue: "$18.5 Miliar"
      }
    },
    data: [
      { year: 2019, rawExport: 1200, processedExport: 400, smelterCount: 9 },
      { year: 2020, rawExport: 100, processedExport: 2500, smelterCount: 13 },
      { year: 2021, rawExport: 0, processedExport: 5800, smelterCount: 19 },
      { year: 2022, rawExport: 0, processedExport: 11200, smelterCount: 27 },
      { year: 2023, rawExport: 0, processedExport: 18500, smelterCount: 34 },
    ]
  },
  {
    id: 'cpo-01',
    name: 'Kelapa Sawit (CPO)',
    type: CommodityType.PALM_OIL,
    reserves: '16.8 Juta Hektar Lahan',
    description: 'Hilirisasi fokus pada Oleofood, Oleochemical, dan Biofuel (B35/B40).',
    location: ['Riau', 'Kalimantan Barat', 'Sumatera Utara'],
    regulations: ['Program Mandatori B35', 'Bea Keluar Ekspor CPO'],
    hsCodes: [
      { code: '1511.10.00', description: 'Crude Palm Oil (CPO)', category: 'Raw', tariff: 7.5 },
      { code: '3826.00.21', description: 'Biodiesel (B35)', category: 'Processed', tariff: 0 },
      { code: '1511.90.20', description: 'RBD Palm Olein', category: 'Processed', tariff: 0 }
    ],
    spotlight: {
      headline: "Revolusi Sawit: Dari CPO ke Biofuel & Oleokimia",
      subHeadline: "Meningkatkan ketahanan energi nasional melalui B35/B40.",
      metrics: {
        valueCreation: "6.5x",
        jobCreation: "4.2 Juta",
        revenue: "$28.5 Miliar"
      }
    },
    data: [
      { year: 2019, rawExport: 8000, processedExport: 12000, smelterCount: 45 },
      { year: 2020, rawExport: 7500, processedExport: 13500, smelterCount: 48 },
      { year: 2021, rawExport: 6000, processedExport: 19000, smelterCount: 52 },
      { year: 2022, rawExport: 5500, processedExport: 24000, smelterCount: 58 },
      { year: 2023, rawExport: 4800, processedExport: 28500, smelterCount: 65 },
    ]
  },
  {
    id: 'bauxite-01',
    name: 'Bauksit (Bauxite)',
    type: CommodityType.BAUXITE,
    reserves: '2.9 Miliar Ton',
    description: 'Bahan baku aluminium. Larangan ekspor bijih bauksit mulai Juni 2023.',
    location: ['Kepulauan Riau', 'Kalimantan Barat'],
    regulations: ['UU Minerba No. 3/2020', 'Pelarangan Ekspor Juni 2023'],
    hsCodes: [
      { code: '2606.00.00', description: 'Bijih Bauksit', category: 'Raw', tariff: 0 },
      { code: '2818.20.00', description: 'Alumina', category: 'Processed', tariff: 0 },
      { code: '7601.10.00', description: 'Aluminium Unwrought', category: 'Processed', tariff: 0 }
    ],
    spotlight: {
      headline: "Kemandirian Aluminium: Progres Smelter Bauksit",
      subHeadline: "Menghentikan ekspor tanah air demi industri aluminium domestik.",
      metrics: {
        valueCreation: "12x",
        jobCreation: "45.000",
        revenue: "$900 Juta"
      }
    },
    data: [
      { year: 2019, rawExport: 800, processedExport: 100, smelterCount: 2 },
      { year: 2020, rawExport: 950, processedExport: 120, smelterCount: 2 },
      { year: 2021, rawExport: 1100, processedExport: 150, smelterCount: 3 },
      { year: 2022, rawExport: 1300, processedExport: 400, smelterCount: 4 },
      { year: 2023, rawExport: 200, processedExport: 900, smelterCount: 6 },
    ]
  },
    {
    id: 'copper-01',
    name: 'Tembaga (Copper)',
    type: CommodityType.COPPER,
    reserves: '2.8 Miliar Ton Bijih',
    description: 'Kunci infrastruktur listrik dan energi terbarukan. Smelter Gresik dan Amman menjadi pusat utama.',
    location: ['Papua', 'Nusa Tenggara Barat'],
    regulations: ['Izin Usaha Pertambangan Khusus (IUPK)'],
    hsCodes: [
      { code: '2603.00.00', description: 'Bijih Tembaga', category: 'Raw', tariff: 10 },
      { code: '7403.11.00', description: 'Katoda Tembaga', category: 'Processed', tariff: 0 }
    ],
    data: [
      { year: 2019, rawExport: 1500, processedExport: 300, smelterCount: 1 },
      { year: 2020, rawExport: 1400, processedExport: 400, smelterCount: 1 },
      { year: 2021, rawExport: 1600, processedExport: 500, smelterCount: 1 },
      { year: 2022, rawExport: 1200, processedExport: 800, smelterCount: 2 },
      { year: 2023, rawExport: 800, processedExport: 1500, smelterCount: 3 },
    ]
  }
];

export const VALUE_CHAINS: ValueChain[] = [
  {
    commodityId: 'nickel-01',
    nodes: [
      { id: 'n1', label: 'Bijih Nikel (Ore)', category: 'Upstream', description: 'Penambangan bijih limonit & saprolit.', valueAdded: '1x', companies: ['PT Antam', 'PT Vale'], priceEstimate: '$30 - $45 / Ton' },
      { id: 'n2', label: 'FeNi / NPI', category: 'Intermediate', description: 'Peleburan bijih menjadi Ferronikel.', valueAdded: '4x', companies: ['IMIP', 'Virtue Dragon'], priceEstimate: '$14,000 / Ton' },
      { id: 'n3', label: 'MHP', category: 'Intermediate', description: 'Proses HPAL untuk bahan baku baterai.', valueAdded: '6x', companies: ['Halmahera Persada'], priceEstimate: '$18,000 / Ton' },
      { id: 'n4', label: 'Stainless Steel', category: 'Downstream', description: 'Produk baja tahan karat.', valueAdded: '10x', companies: ['Tshingshan'], priceEstimate: '$22,000 / Ton' },
      { id: 'n5', label: 'Baterai EV', category: 'Downstream', description: 'Prekursor katoda dan sel baterai.', valueAdded: '19x', companies: ['LG Energy', 'CATL'], priceEstimate: '$45,000 / Ton' },
    ],
    edges: [
      { from: 'n1', to: 'n2' },
      { from: 'n1', to: 'n3' },
      { from: 'n2', to: 'n4' },
      { from: 'n3', to: 'n5' },
    ]
  },
  {
    commodityId: 'cpo-01',
    nodes: [
      { id: 'c1', label: 'Tandan Buah Segar', category: 'Upstream', description: 'Panen kelapa sawit perkebunan.', valueAdded: '1x', companies: ['PTPN', 'Sinar Mas'], priceEstimate: '$150 / Ton' },
      { id: 'c2', label: 'CPO', category: 'Intermediate', description: 'Minyak sawit mentah.', valueAdded: '1.5x', companies: ['Wilmar', 'Musim Mas'], priceEstimate: '$800 / Ton' },
      { id: 'c3', label: 'Refinery (Minyak Goreng)', category: 'Downstream', description: 'Produk pangan utama.', valueAdded: '2.5x', companies: ['Indofood', 'Filma'], priceEstimate: '$1,200 / Ton' },
      { id: 'c4', label: 'Biodiesel (B35)', category: 'Downstream', description: 'Energi terbarukan FAME.', valueAdded: '4x', companies: ['Pertamina'], priceEstimate: '$1,350 / Ton' },
      { id: 'c5', label: 'Oleochemicals', category: 'Downstream', description: 'Kosmetik, sabun, dan farmasi.', valueAdded: '6x', companies: ['Unilever'], priceEstimate: '$2,100 / Ton' },
    ],
    edges: [
      { from: 'c1', to: 'c2' },
      { from: 'c2', to: 'c3' },
      { from: 'c2', to: 'c4' },
      { from: 'c2', to: 'c5' },
    ]
  },
  {
    commodityId: 'bauxite-01',
    nodes: [
      { id: 'b1', label: 'Bijih Bauksit', category: 'Upstream', description: 'Tambang bauksit mentah.', valueAdded: '1x', companies: ['PT Antam'], priceEstimate: '$35 / Ton' },
      { id: 'b2', label: 'Alumina (SGA/CGA)', category: 'Intermediate', description: 'Pemurnian bauksit.', valueAdded: '8x', companies: ['Well Harvest Winning'], priceEstimate: '$400 / Ton' },
      { id: 'b3', label: 'Aluminium Ingot', category: 'Downstream', description: 'Logam aluminium batangan.', valueAdded: '20x', companies: ['Inalum'], priceEstimate: '$2,300 / Ton' },
    ],
    edges: [
      { from: 'b1', to: 'b2' },
      { from: 'b2', to: 'b3' },
    ]
  }
];

export const IMPACT_COMPARISONS: ImpactComparison[] = [
  {
    commodity: 'nickel-01',
    before: {
      year: 2017,
      label: 'Era Ekspor Mentah',
      exportValue: '$3.3 Miliar',
      jobs: '5.000 Pekerja',
      description: 'Ekspor didominasi bijih mentah dengan harga fluktuatif rendah.'
    },
    after: {
      year: 2023,
      label: 'Era Hilirisasi Industri',
      exportValue: '$34.2 Miliar',
      jobs: '120.000+ Pekerja',
      description: 'Ekspor produk turunan (FeNi, Stainless Steel, MHP) bernilai tinggi.'
    }
  },
  {
    commodity: 'cpo-01',
    before: {
      year: 2015,
      label: 'Dominasi CPO Mentah',
      exportValue: '$18 Miliar',
      jobs: '2.1 Juta (Hulu)',
      description: 'Ketergantungan harga pasar global CPO.'
    },
    after: {
      year: 2023,
      label: 'Hilirisasi Pangan & Energi',
      exportValue: '$29 Miliar',
      jobs: '4.2 Juta (Hulu-Hilir)',
      description: 'Diversifikasi ke Biodiesel B35 dan Oleokimia.'
    }
  }
];

export const INDUSTRIAL_ZONES: IndustrialZone[] = [
  {
    id: 'zone-1',
    name: 'IMIP (Indonesia Morowali Industrial Park)',
    location: 'Morowali, Sulawesi Tengah',
    focus: CommodityType.NICKEL,
    coordinates: { x: 55, y: 60 },
    status: 'Beroperasi',
    capacity: '3 Juta Ton Stainless Steel/Tahun',
    jobs: 80000
  },
  {
    id: 'zone-2',
    name: 'IWIP (Indonesia Weda Bay Industrial Park)',
    location: 'Halmahera, Maluku Utara',
    focus: CommodityType.NICKEL,
    coordinates: { x: 75, y: 45 },
    status: 'Beroperasi',
    capacity: '120 Kiloton Nikel-Kobalt/Tahun',
    jobs: 35000
  },
  {
    id: 'zone-3',
    name: 'KEK Sei Mangkei',
    location: 'Simalungun, Sumatera Utara',
    focus: CommodityType.PALM_OIL,
    coordinates: { x: 10, y: 25 },
    status: 'Beroperasi',
    capacity: '2 Juta Ton Oleokimia',
    jobs: 15000
  },
  {
    id: 'zone-4',
    name: 'Freeport Smelter Gresik',
    location: 'Gresik, Jawa Timur',
    focus: CommodityType.COPPER,
    coordinates: { x: 33, y: 78 },
    status: 'Konstruksi',
    capacity: '1.7 Juta Ton Konsentrat Tembaga',
    jobs: 11000
  },
  {
    id: 'zone-5',
    name: 'Smelter Grade Alumina (SGA)',
    location: 'Mempawah, Kalimantan Barat',
    focus: CommodityType.BAUXITE,
    coordinates: { x: 28, y: 55 },
    status: 'Konstruksi',
    capacity: '1 Juta Ton Alumina',
    jobs: 8000
  }
];

export const CALCULATOR_RATIOS: ValueAddedRatio[] = [
  {
    commodityId: 'nickel-01',
    productName: 'Baterai EV',
    rawPrice: 40, // per ton raw ore (illustrative)
    processedPrice: 2400, // per ton processed MHP/Ni
    jobMultiplier: 12, // Jobs per 1000 tons
    taxRate: 0.15
  },
  {
    commodityId: 'cpo-01',
    productName: 'Biodiesel B35',
    rawPrice: 800,
    processedPrice: 1250,
    jobMultiplier: 5,
    taxRate: 0.10
  },
  {
    commodityId: 'bauxite-01',
    productName: 'Aluminium Ingot',
    rawPrice: 35,
    processedPrice: 2200,
    jobMultiplier: 8,
    taxRate: 0.12
  }
];

export const POLICY_LOGS: PolicyLog[] = [
  {
    id: 'pol-1',
    year: 2009,
    title: 'UU Minerba No. 4 Tahun 2009',
    category: 'Law',
    description: 'Landasan hukum utama yang mewajibkan perusahaan tambang untuk melakukan pengolahan dan pemurnian di dalam negeri.',
    impact: 'Memicu rencana pembangunan smelter jangka panjang dan mengubah paradigma dari ekspor tanah air menjadi nilai tambah.'
  },
  {
    id: 'pol-2',
    year: 2014,
    title: 'Pelarangan Ekspor Bijih Mentah (Awal)',
    category: 'Ban',
    description: 'Pemerintah mulai membatasi ekspor mineral mentah tertentu untuk mendorong realisasi pembangunan smelter.',
    impact: 'Penurunan drastis volume ekspor jangka pendek, namun memulai gelombang investasi awal di sektor pemurnian.'
  },
  {
    id: 'pol-3',
    year: 2017,
    title: 'Relaksasi Ekspor Nikel Kadar Rendah',
    category: 'Regulation',
    description: 'Pemerintah memberikan izin sementara ekspor nikel kadar rendah (<1.7%) bagi perusahaan yang sedang membangun smelter.',
    impact: 'Memberikan cashflow bagi penambang untuk membiayai konstruksi smelter yang sedang berjalan.'
  },
  {
    id: 'pol-4',
    year: 2020,
    title: 'Pelarangan Total Ekspor Bijih Nikel',
    category: 'Ban',
    description: 'Pemberlakuan penuh larangan ekspor bijih nikel (semua kadar) efektif 1 Januari 2020 (dipercepat dari 2022).',
    impact: 'Booming investasi smelter RKEF dan HPAL di Morowali dan Halmahera. Indonesia mendominasi pasar nikel global.'
  },
  {
    id: 'pol-5',
    year: 2023,
    title: 'Pelarangan Ekspor Bijih Bauksit',
    category: 'Ban',
    description: 'Mulai Juni 2023, pemerintah melarang ekspor bijih bauksit untuk mendorong industri Alumina dan Aluminium domestik.',
    impact: 'Mendorong percepatan konstruksi Smelter Grade Alumina (SGA) di Kalimantan Barat dan Kepulauan Riau.'
  }
];

export const LIBRARY_RESOURCES: LibraryResource[] = [
  { id: 'res-1', title: 'Grand Strategy Komoditas Mineral & Batubara', category: 'Whitepaper', fileType: 'PDF', fileSize: '4.5 MB', date: '2023-11-15' },
  { id: 'res-2', title: 'Laporan Kinerja Sektor Minerba 2023', category: 'Report', fileType: 'PDF', fileSize: '12 MB', date: '2024-01-20' },
  { id: 'res-3', title: 'Permen ESDM No. 11/2019 tentang Pengusahaan Pertambangan', category: 'Regulation', fileType: 'PDF', fileSize: '850 KB', date: '2019-08-05' },
  { id: 'res-4', title: 'Panduan Investasi Smelter di Indonesia', category: 'Guide', fileType: 'PDF', fileSize: '5.2 MB', date: '2023-06-10' },
  { id: 'res-5', title: 'Analisis Dampak Ekonomi Hilirisasi Nikel (LPEM UI)', category: 'Report', fileType: 'PDF', fileSize: '3.1 MB', date: '2023-09-01' },
];

export const GLOSSARY_TERMS: GlossaryTerm[] = [
  { id: 'term-1', term: 'Smelter', category: 'Teknis', definition: 'Fasilitas pengolahan dan pemurnian mineral tambang untuk meningkatkan kadar logam seperti nikel, tembaga, dan emas.' },
  { id: 'term-2', term: 'Hilirisasi', category: 'Ekonomi', definition: 'Strategi ekonomi untuk mengolah bahan mentah menjadi barang setengah jadi atau jadi di dalam negeri guna meningkatkan nilai tambah.' },
  { id: 'term-3', term: 'HPAL (High Pressure Acid Leaching)', category: 'Teknis', definition: 'Teknologi pengolahan bijih nikel kadar rendah (limonit) menggunakan asam sulfat pada suhu dan tekanan tinggi untuk menghasilkan bahan baku baterai.' },
  { id: 'term-4', term: 'RKEF (Rotary Kiln Electric Furnace)', category: 'Teknis', definition: 'Teknologi pengolahan bijih nikel kadar tinggi (saprolit) secara pirometalurgi untuk menghasilkan feronikel atau nickel pig iron (NPI).' },
  { id: 'term-5', term: 'TKDN (Tingkat Komponen Dalam Negeri)', category: 'Legal', definition: 'Persentase nilai komponen produksi yang dibuat di dalam negeri, yang wajib dipenuhi oleh proyek industri tertentu.' },
  { id: 'term-6', term: 'IUPK (Izin Usaha Pertambangan Khusus)', category: 'Legal', definition: 'Izin untuk melaksanakan usaha pertambangan di wilayah pencadangan negara.' },
];