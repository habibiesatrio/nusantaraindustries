import React, { useState } from 'react';
import { PolicyLog } from '../types';
import { FileText, Gavel, Ban, Award, ChevronDown, ChevronUp } from 'lucide-react';

interface PolicyTimelineProps {
  logs: PolicyLog[];
}

const PolicyTimeline: React.FC<PolicyTimelineProps> = ({ logs }) => {
  const [expandedId, setExpandedId] = useState<string | null>(logs[logs.length - 1].id); // Default expand latest

  const getIcon = (category: PolicyLog['category']) => {
    switch (category) {
      case 'Law': return <Gavel size={18} className="text-purple-400" />;
      case 'Ban': return <Ban size={18} className="text-red-400" />;
      case 'Regulation': return <FileText size={18} className="text-blue-400" />;
      case 'Incentive': return <Award size={18} className="text-green-400" />;
      default: return <FileText size={18} />;
    }
  };

  const getColor = (category: PolicyLog['category']) => {
    switch (category) {
      case 'Law': return 'bg-purple-500/10 border-purple-500/30';
      case 'Ban': return 'bg-red-500/10 border-red-500/30';
      case 'Regulation': return 'bg-blue-500/10 border-blue-500/30';
      case 'Incentive': return 'bg-green-500/10 border-green-500/30';
      default: return 'bg-slate-800 border-slate-700';
    }
  };

  return (
    <div className="relative pl-8 md:pl-0">
      {/* Vertical Line */}
      <div className="absolute left-3 md:left-1/2 top-0 bottom-0 w-0.5 bg-slate-800 -translate-x-1/2"></div>

      <div className="space-y-8">
        {logs.map((log, index) => {
          const isLeft = index % 2 === 0;
          const isExpanded = expandedId === log.id;

          return (
            <div key={log.id} className={`relative flex items-start md:items-center ${isLeft ? 'md:flex-row-reverse' : 'md:flex-row'}`}>
              
              {/* Timeline Dot */}
              <div className="absolute left-3 md:left-1/2 -translate-x-1/2 flex items-center justify-center w-8 h-8 rounded-full bg-slate-900 border-4 border-slate-800 z-10">
                <div className={`w-3 h-3 rounded-full ${isExpanded ? 'bg-nusantara-500 animate-pulse' : 'bg-slate-500'}`}></div>
              </div>

              {/* Spacer for Desktop Centering */}
              <div className="hidden md:block md:w-1/2"></div>

              {/* Content Card */}
              <div className={`w-full md:w-1/2 pl-8 md:pl-0 ${isLeft ? 'md:pr-12' : 'md:pl-12'}`}>
                <div 
                  onClick={() => setExpandedId(isExpanded ? null : log.id)}
                  className={`cursor-pointer rounded-xl border p-5 transition-all duration-300 hover:shadow-lg hover:border-nusantara-500/50 ${getColor(log.category)}`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 bg-slate-900/50 rounded text-xs font-mono text-slate-400 border border-slate-700">
                        {log.year}
                      </span>
                      <div className="flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-slate-300">
                        {getIcon(log.category)}
                        <span>{log.category}</span>
                      </div>
                    </div>
                    {isExpanded ? <ChevronUp size={16} className="text-slate-500" /> : <ChevronDown size={16} className="text-slate-500" />}
                  </div>

                  <h3 className="text-lg font-bold text-white mb-2">{log.title}</h3>
                  
                  <div className={`overflow-hidden transition-all duration-500 ${isExpanded ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
                    <p className="text-slate-400 text-sm mb-4 leading-relaxed">
                      {log.description}
                    </p>
                    <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700/50">
                      <h4 className="text-xs font-bold text-nusantara-400 uppercase mb-1">Dampak Industri:</h4>
                      <p className="text-xs text-slate-300 italic">"{log.impact}"</p>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          );
        })}
      </div>
    </div>
  );
};

export default PolicyTimeline;