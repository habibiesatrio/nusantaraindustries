<?php
require_once 'config.php';

// Fungsi Simulasi Import Data CSV/JSON
function import_data($data) {
    global $conn;
    // Logika untuk memproses array data dan insert ke database commodity_data
    // ... Implementation code ...
    return ["status" => "success", "rows_imported" => count($data)];
}

// Fungsi Fetcher API Eksternal
function fetch_external_data($source) {
    $url = "";
    if ($source == 'bps') $url = "https://webapi.bps.go.id/v1/api/list/model/data/lang/ind/domain/0000/key/YOUR_API_KEY/";
    if ($source == 'hscode') $url = "https://insw.go.id/api/hscode"; // Mock URL

    // Simulasi Fetching
    // $response = file_get_contents($url);
    // return json_decode($response, true);
    
    return ["status" => "simulated_fetch", "source" => $source, "data" => []];
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($action == 'import') {
    $input = json_decode(file_get_contents("php://input"), true);
    if ($input) {
        $result = import_data($input);
        echo json_encode($result);
    }
} elseif ($action == 'sync_external') {
    $source = isset($_GET['source']) ? $_GET['source'] : 'bps';
    $result = fetch_external_data($source);
    echo json_encode($result);
} else {
    echo json_encode(["message" => "Data Service Ready"]);
}
?>