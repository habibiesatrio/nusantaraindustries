import React, { useState } from 'react';
import { KPIMetric, LibraryResource, GlossaryTerm } from '../types';
import { Save, RefreshCw, AlertTriangle, Database, FileText, BookA, Plus, Trash2, X } from 'lucide-react';

interface ERPPanelProps {
  metrics: KPIMetric[];
  onUpdateMetrics: (metrics: KPIMetric[]) => void;
  libraryItems: LibraryResource[];
  onUpdateLibrary: (items: LibraryResource[]) => void;
  glossaryItems: GlossaryTerm[];
  onUpdateGlossary: (items: GlossaryTerm[]) => void;
}

const ERPPanel: React.FC<ERPPanelProps> = ({ 
  metrics, onUpdateMetrics, 
  libraryItems, onUpdateLibrary,
  glossaryItems, onUpdateGlossary
}) => {
  const [activeTab, setActiveTab] = useState<'metrics' | 'library' | 'glossary'>('metrics');
  const [localMetrics, setLocalMetrics] = useState<KPIMetric[]>(metrics);
  const [isSaving, setIsSaving] = useState(false);
  const [lastSync, setLastSync] = useState(new Date().toLocaleTimeString());

  // Form States
  const [showAddLibrary, setShowAddLibrary] = useState(false);
  const [newLib, setNewLib] = useState({ title: '', category: 'Report', fileType: 'PDF', fileSize: '1 MB' });
  const [showAddGlossary, setShowAddGlossary] = useState(false);
  const [newTerm, setNewTerm] = useState({ term: '', definition: '', category: 'Teknis' });

  // Metric Handlers
  const handleMetricChange = (id: string, field: keyof KPIMetric, value: any) => {
    setLocalMetrics(prev => prev.map(m => m.id === id ? { ...m, [field]: value } : m));
  };

  const handleSaveMetrics = async () => {
    setIsSaving(true);
    // Simulation of API Call
    setTimeout(() => {
        onUpdateMetrics(localMetrics);
        setLastSync(new Date().toLocaleTimeString());
        setIsSaving(false);
        alert("Data Indicators Updated Successfully.");
    }, 800);
  };

  // Library Handlers
  const handleAddLibrary = () => {
    if(!newLib.title) return;
    const newItem: LibraryResource = {
        id: `res-${Date.now()}`,
        title: newLib.title,
        category: newLib.category as any,
        fileType: newLib.fileType,
        fileSize: newLib.fileSize,
        date: new Date().toISOString().split('T')[0]
    };
    onUpdateLibrary([newItem, ...libraryItems]);
    setShowAddLibrary(false);
    setNewLib({ title: '', category: 'Report', fileType: 'PDF', fileSize: '1 MB' });
  };

  const handleDeleteLibrary = (id: string) => {
    if(confirm('Hapus dokumen ini?')) {
        onUpdateLibrary(libraryItems.filter(item => item.id !== id));
    }
  };

  // Glossary Handlers
  const handleAddGlossary = () => {
    if(!newTerm.term) return;
    const newItem: GlossaryTerm = {
        id: `term-${Date.now()}`,
        term: newTerm.term,
        definition: newTerm.definition,
        category: newTerm.category
    };
    onUpdateGlossary([newItem, ...glossaryItems]);
    setShowAddGlossary(false);
    setNewTerm({ term: '', definition: '', category: 'Teknis' });
  };

  const handleDeleteGlossary = (id: string) => {
      if(confirm('Hapus istilah ini?')) {
          onUpdateGlossary(glossaryItems.filter(item => item.id !== id));
      }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 mb-8 shadow-xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Database className="text-amber-500" />
            ERP Control Panel (Admin)
          </h2>
          <p className="text-sm text-slate-400">Pusat kontrol data, pustaka, dan konten edukasi.</p>
        </div>
        
        {/* Tab Switcher */}
        <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
           <button 
             onClick={() => setActiveTab('metrics')}
             className={`px-3 py-1.5 text-sm font-medium rounded transition-colors flex items-center gap-2 ${activeTab === 'metrics' ? 'bg-slate-800 text-white' : 'text-slate-500 hover:text-white'}`}
           >
             <Database size={14} /> KPI
           </button>
           <button 
             onClick={() => setActiveTab('library')}
             className={`px-3 py-1.5 text-sm font-medium rounded transition-colors flex items-center gap-2 ${activeTab === 'library' ? 'bg-slate-800 text-white' : 'text-slate-500 hover:text-white'}`}
           >
             <FileText size={14} /> Pustaka
           </button>
           <button 
             onClick={() => setActiveTab('glossary')}
             className={`px-3 py-1.5 text-sm font-medium rounded transition-colors flex items-center gap-2 ${activeTab === 'glossary' ? 'bg-slate-800 text-white' : 'text-slate-500 hover:text-white'}`}
           >
             <BookA size={14} /> Kamus
           </button>
        </div>
      </div>

      {/* METRICS TAB */}
      {activeTab === 'metrics' && (
        <div className="animate-fadeIn">
          <div className="flex justify-end gap-2 mb-4">
            <button className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-sm font-medium border border-slate-700 flex items-center gap-2">
              <RefreshCw size={14} /> Sync BPS Data
            </button>
            <button 
              onClick={handleSaveMetrics}
              disabled={isSaving}
              className="px-4 py-2 bg-nusantara-600 hover:bg-nusantara-500 text-white rounded-lg text-sm font-medium flex items-center gap-2 disabled:opacity-50"
            >
              <Save size={14} /> {isSaving ? 'Saving...' : 'Simpan Perubahan'}
            </button>
          </div>
          <div className="overflow-x-auto rounded-lg border border-slate-800">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="bg-slate-950 uppercase text-xs font-semibold text-slate-500">
                <tr>
                  <th className="px-4 py-3">Indikator Label</th>
                  <th className="px-4 py-3">Value (Display)</th>
                  <th className="px-4 py-3">Change (%)</th>
                  <th className="px-4 py-3">Trend</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 bg-slate-900/50">
                {localMetrics.map((metric) => (
                  <tr key={metric.id}>
                    <td className="px-4 py-2">
                      <input 
                        type="text" value={metric.label}
                        onChange={(e) => handleMetricChange(metric.id, 'label', e.target.value)}
                        className="bg-transparent border border-transparent hover:border-slate-700 focus:border-nusantara-500 rounded px-2 py-1 w-full outline-none"
                      />
                    </td>
                    <td className="px-4 py-2">
                       <input 
                        type="text" value={metric.value}
                        onChange={(e) => handleMetricChange(metric.id, 'value', e.target.value)}
                        className="bg-slate-950 border border-slate-700 rounded px-2 py-1 w-32 outline-none text-white font-mono"
                      />
                    </td>
                    <td className="px-4 py-2">
                       <input 
                        type="number" step="0.1" value={metric.change}
                        onChange={(e) => handleMetricChange(metric.id, 'change', parseFloat(e.target.value))}
                        className="bg-slate-950 border border-slate-700 rounded px-2 py-1 w-20 outline-none text-white font-mono"
                      />
                    </td>
                    <td className="px-4 py-2">
                      <select 
                        value={metric.trend}
                        onChange={(e) => handleMetricChange(metric.id, 'trend', e.target.value)}
                        className="bg-slate-950 border border-slate-700 rounded px-2 py-1 outline-none text-xs"
                      >
                        <option value="up">UP</option>
                        <option value="down">DOWN</option>
                        <option value="neutral">NEUTRAL</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* LIBRARY TAB */}
      {activeTab === 'library' && (
        <div className="animate-fadeIn">
          <div className="flex justify-between items-center mb-4">
             <h3 className="text-white font-semibold">Daftar Dokumen & Regulasi</h3>
             <button 
               onClick={() => setShowAddLibrary(true)}
               className="px-3 py-2 bg-nusantara-600 hover:bg-nusantara-500 text-white rounded-lg text-xs font-medium flex items-center gap-1"
             >
               <Plus size={14} /> Tambah Dokumen
             </button>
          </div>

          {showAddLibrary && (
            <div className="bg-slate-800 p-4 rounded-lg mb-4 border border-slate-700 animate-slideDown">
               <div className="grid grid-cols-2 gap-3 mb-3">
                  <input placeholder="Judul Dokumen" className="col-span-2 bg-slate-900 border border-slate-700 p-2 rounded text-sm text-white outline-none focus:border-nusantara-500" value={newLib.title} onChange={e => setNewLib({...newLib, title: e.target.value})} />
                  <select className="bg-slate-900 border border-slate-700 p-2 rounded text-sm text-white outline-none" value={newLib.category} onChange={e => setNewLib({...newLib, category: e.target.value})}>
                     <option value="Report">Report</option>
                     <option value="Regulation">Regulation</option>
                     <option value="Whitepaper">Whitepaper</option>
                     <option value="Guide">Guide</option>
                  </select>
                  <input placeholder="Ukuran (e.g. 5 MB)" className="bg-slate-900 border border-slate-700 p-2 rounded text-sm text-white outline-none" value={newLib.fileSize} onChange={e => setNewLib({...newLib, fileSize: e.target.value})} />
               </div>
               <div className="flex justify-end gap-2">
                  <button onClick={() => setShowAddLibrary(false)} className="text-xs text-slate-400 hover:text-white px-3 py-1">Batal</button>
                  <button onClick={handleAddLibrary} className="bg-nusantara-600 text-white text-xs px-3 py-1 rounded">Simpan</button>
               </div>
            </div>
          )}

          <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
             {libraryItems.map(item => (
                <div key={item.id} className="flex justify-between items-center bg-slate-950/50 p-3 rounded border border-slate-800 hover:border-slate-700">
                   <div className="flex items-center gap-3">
                      <FileText size={16} className="text-slate-500" />
                      <div>
                         <p className="text-sm text-white font-medium">{item.title}</p>
                         <p className="text-xs text-slate-500">{item.category} • {item.date}</p>
                      </div>
                   </div>
                   <button onClick={() => handleDeleteLibrary(item.id)} className="text-slate-600 hover:text-red-400 p-1">
                      <Trash2 size={16} />
                   </button>
                </div>
             ))}
          </div>
        </div>
      )}

      {/* GLOSSARY TAB */}
      {activeTab === 'glossary' && (
        <div className="animate-fadeIn">
          <div className="flex justify-between items-center mb-4">
             <h3 className="text-white font-semibold">Kamus Istilah Industri</h3>
             <button 
               onClick={() => setShowAddGlossary(true)}
               className="px-3 py-2 bg-nusantara-600 hover:bg-nusantara-500 text-white rounded-lg text-xs font-medium flex items-center gap-1"
             >
               <Plus size={14} /> Tambah Istilah
             </button>
          </div>

          {showAddGlossary && (
            <div className="bg-slate-800 p-4 rounded-lg mb-4 border border-slate-700 animate-slideDown">
               <div className="space-y-3 mb-3">
                  <div className="flex gap-3">
                     <input placeholder="Istilah (Term)" className="flex-1 bg-slate-900 border border-slate-700 p-2 rounded text-sm text-white outline-none focus:border-nusantara-500" value={newTerm.term} onChange={e => setNewTerm({...newTerm, term: e.target.value})} />
                     <input placeholder="Kategori" className="w-1/3 bg-slate-900 border border-slate-700 p-2 rounded text-sm text-white outline-none" value={newTerm.category} onChange={e => setNewTerm({...newTerm, category: e.target.value})} />
                  </div>
                  <textarea placeholder="Definisi..." className="w-full bg-slate-900 border border-slate-700 p-2 rounded text-sm text-white outline-none h-20" value={newTerm.definition} onChange={e => setNewTerm({...newTerm, definition: e.target.value})} />
               </div>
               <div className="flex justify-end gap-2">
                  <button onClick={() => setShowAddGlossary(false)} className="text-xs text-slate-400 hover:text-white px-3 py-1">Batal</button>
                  <button onClick={handleAddGlossary} className="bg-nusantara-600 text-white text-xs px-3 py-1 rounded">Simpan</button>
               </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[400px] overflow-y-auto pr-1">
             {glossaryItems.map(item => (
                <div key={item.id} className="relative bg-slate-950/50 p-3 rounded border border-slate-800 hover:border-slate-700 group">
                   <button onClick={() => handleDeleteGlossary(item.id)} className="absolute top-2 right-2 text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Trash2 size={14} />
                   </button>
                   <p className="text-sm text-nusantara-400 font-bold mb-1">{item.term} <span className="text-[10px] text-slate-500 font-normal border border-slate-700 px-1 rounded ml-1">{item.category}</span></p>
                   <p className="text-xs text-slate-400 line-clamp-2">{item.definition}</p>
                </div>
             ))}
          </div>
        </div>
      )}

      {/* Footer Info */}
      <div className="mt-6 pt-4 border-t border-slate-800 flex justify-between items-center text-xs text-slate-500">
         <div className="flex items-center gap-1 text-amber-500">
            <AlertTriangle size={12} />
            <span>Mode Admin Aktif</span>
         </div>
         <span>Last Sync: {lastSync}</span>
      </div>
    </div>
  );
};

export default ERPPanel;