import React, { useState } from 'react';
import { ValueChain } from '../types';
import { Tag, Sprout, ArrowUp, Snowflake, Layers } from 'lucide-react';

interface IndustryTreeGalleryProps {
  chains: ValueChain[];
}

const IndustryTreeGallery: React.FC<IndustryTreeGalleryProps> = ({ chains }) => {
  const [selectedChainId, setSelectedChainId] = useState(chains[0].commodityId);
  const activeChain = chains.find(c => c.commodityId === selectedChainId) || chains[0];

  const upstream = activeChain.nodes.filter(n => n.category === 'Upstream')[0];
  const intermediate = activeChain.nodes.filter(n => n.category === 'Intermediate')[0];
  const downstreamNodes = activeChain.nodes.filter(n => n.category === 'Downstream');

  // Simple formatter for commodity names to show in tabs
  const getCommodityName = (id: string) => {
    if(id.includes('nickel')) return 'Nikel';
    if(id.includes('cpo')) return 'Sawit';
    if(id.includes('bauxite')) return 'Bauksit';
    return 'Komoditas';
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-8 shadow-xl">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div>
          <h3 className="text-2xl font-bold text-white flex items-center gap-2">
            <Sprout className="text-green-500" />
            Galeri Pohon Industri
          </h3>
          <p className="text-slate-400 text-sm">Visualisasi transformasi nilai dari akar (mentah) hingga daun (produk jadi).</p>
        </div>
        <div className="flex bg-slate-800 p-1 rounded-lg">
           {chains.map(chain => (
             <button
               key={chain.commodityId}
               onClick={() => setSelectedChainId(chain.commodityId)}
               className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                 selectedChainId === chain.commodityId 
                  ? 'bg-nusantara-600 text-white shadow-lg' 
                  : 'text-slate-400 hover:text-white'
               }`}
             >
               {getCommodityName(chain.commodityId)}
             </button>
           ))}
        </div>
      </div>

      {/* Tree Visualization Container */}
      <div className="relative min-h-[500px] flex flex-col items-center justify-end py-8">
        
        {/* Decorative Tree Background Line */}
        <div className="absolute top-10 bottom-20 left-1/2 w-2 bg-slate-800 rounded-full -translate-x-1/2 z-0"></div>

        {/* 1. LEAVES (Downstream) */}
        <div className="relative z-10 w-full mb-16">
          <div className="flex justify-center gap-4 flex-wrap">
            {downstreamNodes.map((node, idx) => (
              <div key={idx} className="group relative">
                {/* Connecting Line to Trunk */}
                <div className="absolute top-full left-1/2 w-0.5 h-16 bg-slate-700 -translate-x-1/2 group-hover:bg-nusantara-500/50 transition-colors"></div>
                
                <div className="bg-slate-800 border-2 border-slate-700 group-hover:border-nusantara-500 p-4 rounded-xl w-48 text-center transition-all cursor-help shadow-lg transform group-hover:-translate-y-1">
                  <div className="inline-block p-2 bg-nusantara-900/50 rounded-full mb-2 text-nusantara-400">
                    <Snowflake size={20} />
                  </div>
                  <h4 className="text-white font-bold text-sm mb-1">{node.label}</h4>
                  <p className="text-xs text-slate-400 line-clamp-2">{node.description}</p>
                  
                  {/* Price Tag (Revealed on Hover) */}
                  <div className="absolute inset-x-0 bottom-full mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                     <div className="bg-green-600 text-white text-xs py-1 px-2 rounded shadow-lg mx-auto w-max mb-1">
                        Est. {node.priceEstimate}
                     </div>
                     <div className="w-2 h-2 bg-green-600 rotate-45 mx-auto -mb-1"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-2">
             <span className="bg-slate-900 text-slate-500 text-xs px-2 py-1 rounded border border-slate-800 uppercase tracking-widest">Produk Hilir (High Value)</span>
          </div>
        </div>

        {/* 2. TRUNK (Intermediate) */}
        <div className="relative z-10 mb-16">
           <div className="bg-slate-800 border-2 border-slate-600 p-6 rounded-2xl w-64 text-center shadow-xl">
              <div className="inline-block p-3 bg-blue-900/30 rounded-full mb-2 text-blue-400">
                <Layers size={24} />
              </div>
              <h4 className="text-white font-bold text-lg mb-1">{intermediate?.label || 'Processing'}</h4>
              <p className="text-xs text-slate-400 mb-2">{intermediate?.description}</p>
              <span className="text-xs font-mono text-blue-300 bg-blue-900/20 px-2 py-1 rounded">
                Nilai Tambah: {intermediate?.valueAdded}
              </span>
           </div>
           {/* Trunk Label */}
           <div className="absolute top-1/2 -right-32 -translate-y-1/2 text-left hidden md:block">
              <div className="text-xs text-slate-500 uppercase font-bold mb-1">Proses Antara</div>
              <div className="w-8 h-0.5 bg-slate-700"></div>
           </div>
        </div>

        {/* 3. ROOT (Upstream) */}
        <div className="relative z-10">
           <div className="bg-slate-900 border-2 border-slate-700 border-dashed p-6 rounded-2xl w-64 text-center shadow-xl">
              <div className="inline-block p-3 bg-amber-900/20 rounded-full mb-2 text-amber-500">
                <ArrowUp size={24} />
              </div>
              <h4 className="text-white font-bold text-lg mb-1">{upstream?.label || 'Raw Material'}</h4>
              <p className="text-xs text-slate-400 mb-2">{upstream?.description}</p>
              <div className="text-xs font-mono text-amber-500 bg-amber-900/10 px-2 py-1 rounded inline-block">
                 Base Price: {upstream?.priceEstimate}
              </div>
           </div>
            <div className="text-center mt-4">
             <span className="bg-slate-950 text-slate-600 text-xs px-2 py-1 rounded uppercase tracking-widest">Bahan Mentah (Low Value)</span>
          </div>
        </div>

      </div>
    </div>
  );
};

export default IndustryTreeGallery;