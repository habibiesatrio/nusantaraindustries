import React from 'react';
import { LayoutDashboard, Factory, TrendingUp, FileText, Settings, Database } from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard Utama', icon: LayoutDashboard },
    { id: 'commodities', label: 'Data Komoditas', icon: Database },
    { id: 'analysis', label: 'AI Intelligence', icon: TrendingUp },
    { id: 'reports', label: 'Laporan Ekspor', icon: FileText },
    { id: 'infrastructure', label: 'Peta Smelter', icon: Factory },
  ];

  return (
    <div className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col h-full hidden md:flex">
      <div className="p-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-nusantara-600 rounded-lg flex items-center justify-center">
            <Factory className="text-white w-5 h-5" />
          </div>
          <div>
            <h1 className="text-white font-bold text-lg leading-none">Nusantara</h1>
            <span className="text-nusantara-400 text-xs font-medium tracking-wider">INDUSTRIE</span>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 ${
                isActive
                  ? 'bg-nusantara-600/10 text-nusantara-400 border border-nusantara-600/20'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon size={18} />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <button className="w-full flex items-center gap-3 px-4 py-3 text-sm font-medium text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors">
          <Settings size={18} />
          Pengaturan Sistem
        </button>
        <div className="mt-4 px-4 py-3 bg-slate-800 rounded-lg">
          <p className="text-xs text-slate-400">Status Server</p>
          <div className="flex items-center gap-2 mt-1">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
            <span className="text-xs text-white font-mono">ONLINE</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1 truncate">DB: u724...nustaraid</p>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;