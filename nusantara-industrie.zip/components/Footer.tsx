import React from 'react';
import { Facebook, Twitter, Instagram, Linkedin, Mail, MapPin, Phone } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 pt-16 pb-8 border-t border-slate-900 text-slate-400 text-sm">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-1">
             <h3 className="text-white font-bold text-lg mb-4">Nusantara Industrie</h3>
             <p className="leading-relaxed mb-6">
               Pusat Data & Pelacakan Hilirisasi Indonesia. Mendorong transparansi dan investasi berbasis data untuk kemajuan industri nasional.
             </p>
             <div className="flex gap-4">
               <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center hover:bg-nusantara-600 hover:text-white transition-all"><Twitter size={18} /></a>
               <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center hover:bg-nusantara-600 hover:text-white transition-all"><Linkedin size={18} /></a>
               <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center hover:bg-nusantara-600 hover:text-white transition-all"><Instagram size={18} /></a>
             </div>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Navigasi Cepat</h4>
            <ul className="space-y-3">
              <li><a href="#" className="hover:text-nusantara-400 transition-colors">Beranda</a></li>
              <li><a href="#" className="hover:text-nusantara-400 transition-colors">Data Tracking</a></li>
              <li><a href="#" className="hover:text-nusantara-400 transition-colors">Peta Sebaran Smelter</a></li>
              <li><a href="#" className="hover:text-nusantara-400 transition-colors">Regulasi & Kebijakan</a></li>
            </ul>
          </div>

          <div>
             <h4 className="text-white font-semibold mb-4">Layanan Data</h4>
             <ul className="space-y-3">
              <li><a href="#" className="hover:text-nusantara-400 transition-colors">API Publik (BPS Integrated)</a></li>
              <li><a href="#" className="hover:text-nusantara-400 transition-colors">Laporan Hilirisasi Tahunan</a></li>
              <li><a href="#" className="hover:text-nusantara-400 transition-colors">Kalkulator Investasi</a></li>
              <li><a href="#" className="hover:text-nusantara-400 transition-colors">Portal Investor</a></li>
            </ul>
          </div>

          <div>
             <h4 className="text-white font-semibold mb-4">Hubungi Kami</h4>
             <ul className="space-y-4">
               <li className="flex items-start gap-3">
                 <MapPin className="shrink-0 text-nusantara-500" size={18} />
                 <span>Gedung Kementerian Perindustrian, Jl. Gatot Subroto Kav. 52-53, Jakarta Selatan</span>
               </li>
               <li className="flex items-center gap-3">
                 <Phone className="shrink-0 text-nusantara-500" size={18} />
                 <span>+62 21 5255 509</span>
               </li>
               <li className="flex items-center gap-3">
                 <Mail className="shrink-0 text-nusantara-500" size={18} />
                 <span>data@kemenperin.go.id</span>
               </li>
             </ul>
          </div>
        </div>

        <div className="border-t border-slate-900 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p>&copy; 2024 Nusantara Industrie. Hak Cipta Dilindungi Undang-Undang.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-nusantara-400">Kebijakan Privasi</a>
            <a href="#" className="hover:text-nusantara-400">Syarat Penggunaan</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;