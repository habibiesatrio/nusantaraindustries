import React, { useState } from 'react';
import { LibraryResource } from '../types';
import { FileText, Download, Search, Filter } from 'lucide-react';

interface ResourceLibraryProps {
  data: LibraryResource[];
}

const ResourceLibrary: React.FC<ResourceLibraryProps> = ({ data }) => {
  const [filter, setFilter] = useState('All');
  const [search, setSearch] = useState('');

  const filteredResources = data.filter(res => {
    const matchCat = filter === 'All' || res.category === filter;
    const matchSearch = res.title.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const categories = ['All', 'Report', 'Regulation', 'Whitepaper', 'Guide'];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
           <h3 className="text-2xl font-bold text-white mb-2">Pustaka & Regulasi</h3>
           <p className="text-slate-400 text-sm">Dokumen resmi, laporan BPS, dan panduan investasi hilirisasi.</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
          <div className="relative">
             <Search className="absolute left-3 top-2.5 text-slate-500 w-4 h-4" />
             <input 
               type="text" 
               placeholder="Cari dokumen..."
               value={search}
               onChange={(e) => setSearch(e.target.value)}
               className="bg-slate-950 border border-slate-700 text-white pl-9 pr-4 py-2 rounded-lg text-sm focus:border-nusantara-500 outline-none w-full"
             />
          </div>
          <div className="flex gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 overflow-x-auto">
             {categories.map(cat => (
               <button
                 key={cat}
                 onClick={() => setFilter(cat)}
                 className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                   filter === cat ? 'bg-slate-800 text-white' : 'text-slate-500 hover:text-slate-300'
                 }`}
               >
                 {cat}
               </button>
             ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredResources.map((res) => (
          <div key={res.id} className="group flex items-start gap-4 p-4 bg-slate-950/50 border border-slate-800 hover:border-nusantara-500/50 rounded-xl transition-all hover:bg-slate-900">
            <div className="p-3 bg-slate-800 rounded-lg group-hover:bg-nusantara-900/50 transition-colors">
              <FileText className="text-nusantara-400" size={24} />
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-start">
                 <div>
                   <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded mb-2 inline-block ${
                      res.category === 'Regulation' ? 'bg-purple-500/10 text-purple-400' :
                      res.category === 'Report' ? 'bg-blue-500/10 text-blue-400' :
                      'bg-slate-700 text-slate-300'
                   }`}>
                     {res.category}
                   </span>
                   <h4 className="text-white font-semibold text-sm leading-tight mb-1 group-hover:text-nusantara-400 transition-colors">{res.title}</h4>
                   <p className="text-xs text-slate-500">{res.date} • {res.fileType} • {res.fileSize}</p>
                 </div>
                 <button className="p-2 text-slate-500 hover:text-white hover:bg-slate-800 rounded-lg transition-colors" title="Download">
                   <Download size={18} />
                 </button>
              </div>
            </div>
          </div>
        ))}
        
        {filteredResources.length === 0 && (
          <div className="col-span-full text-center py-12 text-slate-500 text-sm">
            Tidak ada dokumen yang cocok dengan pencarian Anda.
          </div>
        )}
      </div>
    </div>
  );
};

export default ResourceLibrary;