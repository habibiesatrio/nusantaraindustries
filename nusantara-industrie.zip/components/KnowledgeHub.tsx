import React from 'react';
import { POLICY_LOGS, VALUE_CHAINS } from '../services/mockData';
import { LibraryResource, GlossaryTerm } from '../types';
import PolicyTimeline from './PolicyTimeline';
import IndustryTreeGallery from './IndustryTreeGallery';
import ResourceLibrary from './ResourceLibrary';
import Glossary from './Glossary';
import { BookOpen, History, Lightbulb } from 'lucide-react';

interface KnowledgeHubProps {
  libraryItems: LibraryResource[];
  glossaryItems: GlossaryTerm[];
}

const KnowledgeHub: React.FC<KnowledgeHubProps> = ({ libraryItems, glossaryItems }) => {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-16 max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-nusantara-900/30 rounded-full border border-nusantara-500/20 text-nusantara-400 text-sm font-medium mb-4">
          <BookOpen size={16} />
          <span>Pusat Edukasi Hilirisasi</span>
        </div>
        <h1 className="text-3xl md:text-5xl font-bold text-white mb-6">
          Memahami Perjalanan <span className="text-nusantara-500">Transformasi Ekonomi</span>
        </h1>
        <p className="text-lg text-slate-400 leading-relaxed">
          Eksplorasi sejarah kebijakan, dasar hukum, dan dampak strategis dari langkah Indonesia menghentikan ekspor bahan mentah demi kedaulatan industri.
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 md:p-12 shadow-2xl relative overflow-hidden mb-16">
        {/* Decorative Background */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-nusantara-600/5 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>

        <div className="flex items-center gap-3 mb-10 pb-6 border-b border-slate-800">
           <div className="p-3 bg-nusantara-600 rounded-lg shadow-lg shadow-nusantara-600/20">
             <History className="text-white w-6 h-6" />
           </div>
           <div>
             <h2 className="text-2xl font-bold text-white">Timeline Kebijakan Nasional</h2>
             <p className="text-slate-400 text-sm">Rekam jejak regulasi UU Minerba dan pelarangan ekspor.</p>
           </div>
        </div>

        <PolicyTimeline logs={POLICY_LOGS} />
        
        <div className="mt-12 pt-8 border-t border-slate-800 text-center">
           <div className="inline-flex items-center gap-2 text-sm text-slate-500 bg-slate-950 px-4 py-2 rounded-lg border border-slate-800">
             <Lightbulb size={16} className="text-amber-400" />
             <span className="italic">Tahukah Anda? Pelarangan ekspor nikel 2020 meningkatkan nilai ekspor produk turunan hingga 10x lipat dalam 3 tahun.</span>
           </div>
        </div>
      </div>

      {/* Module 2: Industry Tree Gallery */}
      <div className="mb-16">
        <IndustryTreeGallery chains={VALUE_CHAINS} />
      </div>

      {/* Modules 3 & 4: Resource Library & Glossary Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <ResourceLibrary data={libraryItems} />
        <Glossary data={glossaryItems} />
      </div>
    </div>
  );
};

export default KnowledgeHub;