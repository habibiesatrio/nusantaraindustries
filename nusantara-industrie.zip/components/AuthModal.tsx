import React, { useState } from 'react';
import { X, User, Lock, Mail, ArrowRight, Loader2, AlertCircle } from 'lucide-react';
import { User as UserType } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (user: UserType) => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLogin }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({ email: '', password: '', name: '' });

  if (!isOpen) return null;

  const performMockLogin = async () => {
    // Simulasi delay jaringan
    await new Promise(r => setTimeout(r, 800));

    const isAdmin = formData.email === 'admin@nusantaraindustrie.com';
    
    // Validasi Password Mock
    // Admin password harus: Hilirisasi2024!#
    // User biasa bebas passwordnya untuk demo
    if (isAdmin && formData.password !== 'Hilirisasi2024!#') {
         throw new Error('Password salah untuk akun Admin (Hint: Hilirisasi2024!#)');
    }

    return {
       status: 'success',
       user: {
         id: isAdmin ? 'admin-01' : 'user-' + Date.now(),
         name: formData.name || (isAdmin ? 'Super Admin' : 'Investor Demo'),
         email: formData.email,
         role: isAdmin ? 'admin' : 'investor'
       } as UserType
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    const LOGIN_API = '/api/auth/process_login.php';
    const REGISTER_API = '/api/auth/process_login.php?action=register'; 
    const API_URL = isRegister ? REGISTER_API : LOGIN_API;

    try {
      let data;
      let usedMock = false;

      try {
        // Coba hubungi API Backend
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        });
        
        const contentType = response.headers.get("content-type");
        if (!response.ok || !contentType || !contentType.includes("application/json")) {
           throw new Error("API Backend tidak tersedia, beralih ke Mode Demo.");
        }

        data = await response.json();
        
      } catch (backendError) {
        // FALLBACK: Jika Backend Error/404 (Dev Mode), gunakan Mock Login
        console.warn("Menggunakan Mock Login karena Backend tidak terdeteksi:", backendError);
        data = await performMockLogin();
        usedMock = true;
      }

      if (data && data.user) {
        onLogin(data.user);
        onClose();
        if(usedMock) {
           // Opsional: Memberi tahu user bahwa ini mode demo
           console.log("Login berhasil dalam Mode Demo");
        }
      } else {
        throw new Error(data.message || 'Login gagal.');
      }

    } catch (err: any) {
      setError(err.message || 'Terjadi kesalahan sistem.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm" onClick={onClose}></div>
      
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-8 overflow-hidden animate-fadeIn">
        <div className="absolute top-0 right-0 w-32 h-32 bg-nusantara-600/10 rounded-full blur-2xl -mr-16 -mt-16 pointer-events-none"></div>
        
        <button 
          onClick={onClose}
          className="absolute right-4 top-4 text-slate-500 hover:text-white transition-colors"
        >
          <X size={20} />
        </button>

        <div className="mb-6">
          <h2 className="text-2xl font-bold text-white mb-2">
            {isRegister ? 'Daftar Akun Baru' : 'Login Portal ERP'}
          </h2>
          <p className="text-slate-400 text-sm">
            {isRegister 
              ? 'Akses data eksklusif untuk investor dan pejabat publik.' 
              : 'Masuk untuk mengakses Dashboard Kontrol & Analisis.'}
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center gap-2 text-red-400 text-sm">
            <AlertCircle size={16} />
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
             <div className="space-y-1">
              <label className="text-xs text-slate-400 font-medium ml-1">Nama Lengkap</label>
              <div className="relative">
                <User size={16} className="absolute left-3 top-3.5 text-slate-500" />
                <input 
                  type="text" 
                  required
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg pl-10 pr-4 py-3 text-sm focus:border-nusantara-500 outline-none"
                  placeholder="Nama Lengkap"
                />
              </div>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-xs text-slate-400 font-medium ml-1">Email Pemerintahan / Korporat</label>
            <div className="relative">
              <Mail size={16} className="absolute left-3 top-3.5 text-slate-500" />
              <input 
                type="email" 
                required
                value={formData.email}
                onChange={e => setFormData({...formData, email: e.target.value})}
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg pl-10 pr-4 py-3 text-sm focus:border-nusantara-500 outline-none"
                placeholder="admin@nusantaraindustrie.com"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-slate-400 font-medium ml-1">Password</label>
            <div className="relative">
              <Lock size={16} className="absolute left-3 top-3.5 text-slate-500" />
              <input 
                type="password" 
                required
                value={formData.password}
                onChange={e => setFormData({...formData, password: e.target.value})}
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg pl-10 pr-4 py-3 text-sm focus:border-nusantara-500 outline-none"
                placeholder="••••••••"
              />
            </div>
          </div>

          <button 
            type="submit" 
            disabled={isLoading}
            className="w-full bg-nusantara-600 hover:bg-nusantara-500 text-white font-bold py-3 rounded-lg mt-6 transition-all flex items-center justify-center gap-2"
          >
            {isLoading ? <Loader2 className="animate-spin" size={20} /> : (
              <>
                {isRegister ? 'Buat Akun' : 'Masuk Portal'}
                <ArrowRight size={18} />
              </>
            )}
          </button>
        </form>

        <div className="mt-6 text-center text-sm text-slate-500">
          {isRegister ? 'Sudah punya akun? ' : 'Belum punya akun? '}
          <button 
            onClick={() => setIsRegister(!isRegister)}
            className="text-nusantara-400 hover:text-nusantara-300 font-medium"
          >
            {isRegister ? 'Login disini' : 'Daftar sekarang'}
          </button>
        </div>
        
        {/* Helper untuk Demo */}
        {!isRegister && (
          <div className="mt-4 pt-4 border-t border-slate-800 text-[10px] text-slate-600 text-center">
            <p>Demo Admin: admin@nusantaraindustrie.com / Hilirisasi2024!#</p>
            <p>Demo Investor: (Email bebas) / (Password bebas)</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AuthModal;