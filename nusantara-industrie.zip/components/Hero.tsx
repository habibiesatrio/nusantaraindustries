import React, { useState, useEffect } from 'react';
import { ChevronRight, BarChart2, TrendingUp, Users, DollarSign, Activity } from 'lucide-react';
import { COMMODITIES } from '../services/mockData';
import { AreaChart, Area, XAxis, Tooltip, ResponsiveContainer } from 'recharts';

interface HeroProps {
  onStartTracking: () => void;
}

const Hero: React.FC<HeroProps> = ({ onStartTracking }) => {
  // Filter only commodities that have spotlight data
  const spotlightCommodities = COMMODITIES.filter(c => c.spotlight);
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((current) => (current + 1) % spotlightCommodities.length);
    }, 8000); // Rotate every 8 seconds

    return () => clearInterval(interval);
  }, [spotlightCommodities.length]);

  const currentCommodity = spotlightCommodities[activeIndex];
  const spotlight = currentCommodity.spotlight!;

  return (
    <section className="relative w-full py-16 lg:py-20 overflow-hidden bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-nusantara-600/10 rounded-full blur-3xl opacity-50 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl opacity-50 pointer-events-none"></div>

      <div className="container mx-auto px-4 relative z-10">
        
        {/* Top Navigation Tabs */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex bg-slate-800/50 p-1 rounded-full border border-slate-700 backdrop-blur-sm">
            {spotlightCommodities.map((item, idx) => (
              <button
                key={item.id}
                onClick={() => setActiveIndex(idx)}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  idx === activeIndex 
                    ? 'bg-nusantara-600 text-white shadow-lg' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {item.name.split(' ')[0]}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Column: Text & Metrics */}
          <div className="space-y-8 animate-fadeIn">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-nusantara-900/50 border border-nusantara-500/30 text-nusantara-400 text-xs font-semibold mb-4">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                Spotlight Komoditas Strategis
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold text-white mb-4 leading-tight">
                {spotlight.headline}
              </h1>
              <p className="text-lg text-slate-400 border-l-4 border-nusantara-500 pl-4">
                {spotlight.subHeadline}
              </p>
            </div>

            {/* Dynamic Key Metrics */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-slate-800/50 border border-slate-700 p-4 rounded-xl">
                <div className="flex items-center gap-2 text-slate-400 text-xs mb-2">
                  <TrendingUp size={14} className="text-nusantara-400" />
                  Value Added
                </div>
                <div className="text-2xl font-bold text-white">{spotlight.metrics.valueCreation}</div>
                <div className="text-[10px] text-slate-500">Nilai Tambah</div>
              </div>
              <div className="bg-slate-800/50 border border-slate-700 p-4 rounded-xl">
                <div className="flex items-center gap-2 text-slate-400 text-xs mb-2">
                  <Users size={14} className="text-green-400" />
                  Job Creation
                </div>
                <div className="text-2xl font-bold text-white">{spotlight.metrics.jobCreation}</div>
                <div className="text-[10px] text-slate-500">Tenaga Kerja</div>
              </div>
              <div className="bg-slate-800/50 border border-slate-700 p-4 rounded-xl">
                <div className="flex items-center gap-2 text-slate-400 text-xs mb-2">
                  <DollarSign size={14} className="text-amber-400" />
                  Export Rev
                </div>
                <div className="text-2xl font-bold text-white">{spotlight.metrics.revenue}</div>
                <div className="text-[10px] text-slate-500">Pendapatan 2023</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button 
                onClick={onStartTracking}
                className="group inline-flex items-center justify-center gap-2 px-8 py-3 bg-nusantara-600 hover:bg-nusantara-500 text-white font-semibold rounded-lg transition-all hover:shadow-[0_0_20px_rgba(14,165,233,0.3)]"
              >
                Lihat Data Lengkap
                <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

          {/* Right Column: Mini Chart Visualization */}
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-nusantara-600/20 to-transparent rounded-2xl blur-xl"></div>
            <div className="relative bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl">
              <div className="flex justify-between items-center mb-6">
                <div>
                   <h3 className="text-lg font-bold text-white flex items-center gap-2">
                     <Activity className="text-nusantara-400" size={18} />
                     Tren Nilai Tambah
                   </h3>
                   <p className="text-xs text-slate-400">Gap Profit: Ekspor Mentah vs Hilir</p>
                </div>
                <div className="px-2 py-1 bg-slate-800 rounded text-xs text-slate-400 font-mono">
                  2019 - 2023
                </div>
              </div>

              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={currentCommodity.data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorProcessed" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorRaw" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#64748b" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#64748b" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="year" stroke="#475569" fontSize={12} tickLine={false} axisLine={false} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                      itemStyle={{ padding: 0 }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="processedExport" 
                      name="Produk Hilir ($M)"
                      stroke="#0ea5e9" 
                      fillOpacity={1} 
                      fill="url(#colorProcessed)" 
                      strokeWidth={3}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="rawExport" 
                      name="Bijih Mentah ($M)"
                      stroke="#64748b" 
                      fillOpacity={1} 
                      fill="url(#colorRaw)" 
                      strokeDasharray="5 5"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <div className="mt-4 flex items-center justify-center gap-6 text-xs text-slate-400">
                 <div className="flex items-center gap-2">
                   <span className="w-3 h-1 bg-slate-500 rounded-full"></span>
                   Ekspor Mentah (Raw)
                 </div>
                 <div className="flex items-center gap-2">
                   <span className="w-3 h-1 bg-nusantara-500 rounded-full"></span>
                   Produk Hilir (Value Added)
                 </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;