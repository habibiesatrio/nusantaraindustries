import React, { useState } from 'react';
import { ValueChain, ValueChainNode } from '../types';
import { ChevronRight, Info, Building2, TrendingUp, X } from 'lucide-react';

interface ValueChainTreeProps {
  chains: ValueChain[];
}

const ValueChainTree: React.FC<ValueChainTreeProps> = ({ chains }) => {
  const [selectedChainId, setSelectedChainId] = useState(chains[0].commodityId);
  const [selectedNode, setSelectedNode] = useState<ValueChainNode | null>(null);

  const activeChain = chains.find(c => c.commodityId === selectedChainId) || chains[0];
  
  // Helper to categorize nodes
  const upstream = activeChain.nodes.filter(n => n.category === 'Upstream');
  const intermediate = activeChain.nodes.filter(n => n.category === 'Intermediate');
  const downstream = activeChain.nodes.filter(n => n.category === 'Downstream');

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden mb-8">
      <div className="p-6 border-b border-slate-800 flex justify-between items-center">
        <div>
           <h3 className="text-xl font-bold text-white flex items-center gap-2">
             <TrendingUp className="text-nusantara-500" />
             Pohon Industri Digital
           </h3>
           <p className="text-sm text-slate-400">Visualisasi rantai nilai tambah dari hulu ke hilir.</p>
        </div>
        <select 
          value={selectedChainId}
          onChange={(e) => setSelectedChainId(e.target.value)}
          className="bg-slate-950 border border-slate-700 text-white px-4 py-2 rounded-lg text-sm outline-none focus:border-nusantara-500"
        >
          <option value="nickel-01">Nikel</option>
          <option value="cpo-01">Kelapa Sawit</option>
          <option value="bauxite-01">Bauksit</option>
        </select>
      </div>

      <div className="p-8 relative min-h-[400px] overflow-x-auto">
        <div className="flex justify-between items-start min-w-[800px] gap-8">
          
          {/* Upstream Column */}
          <div className="flex-1 space-y-8 relative">
             <div className="text-center mb-6">
                <span className="px-3 py-1 bg-slate-800 rounded-full text-xs font-bold text-slate-400 border border-slate-700">HULU (Upstream)</span>
             </div>
             {upstream.map(node => (
               <NodeCard key={node.id} node={node} onClick={() => setSelectedNode(node)} />
             ))}
          </div>

          {/* Connector Column 1 */}
          <div className="flex flex-col justify-center items-center py-20">
             <ChevronRight className="text-slate-600 w-8 h-8" />
          </div>

          {/* Intermediate Column */}
          <div className="flex-1 space-y-8">
             <div className="text-center mb-6">
                <span className="px-3 py-1 bg-slate-800 rounded-full text-xs font-bold text-slate-400 border border-slate-700">ANTARA (Intermediate)</span>
             </div>
             {intermediate.map(node => (
               <NodeCard key={node.id} node={node} onClick={() => setSelectedNode(node)} />
             ))}
          </div>

           {/* Connector Column 2 */}
          <div className="flex flex-col justify-center items-center py-20">
             <ChevronRight className="text-slate-600 w-8 h-8" />
          </div>

          {/* Downstream Column */}
          <div className="flex-1 space-y-8">
             <div className="text-center mb-6">
                <span className="px-3 py-1 bg-slate-800 rounded-full text-xs font-bold text-slate-400 border border-slate-700">HILIR (Downstream)</span>
             </div>
             {downstream.map(node => (
               <NodeCard key={node.id} node={node} onClick={() => setSelectedNode(node)} />
             ))}
          </div>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedNode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm" onClick={() => setSelectedNode(null)}></div>
          <div className="relative bg-slate-900 border border-slate-700 rounded-xl p-6 max-w-md w-full shadow-2xl animate-fadeIn">
            <button 
              onClick={() => setSelectedNode(null)}
              className="absolute right-4 top-4 text-slate-400 hover:text-white"
            >
              <X size={20} />
            </button>
            
            <div className="flex items-center gap-3 mb-4">
               <div className="w-10 h-10 bg-nusantara-600/20 rounded-lg flex items-center justify-center border border-nusantara-500/30">
                 <Info className="text-nusantara-400" />
               </div>
               <div>
                 <p className="text-xs text-slate-400 uppercase tracking-wide">{selectedNode.category}</p>
                 <h3 className="text-xl font-bold text-white">{selectedNode.label}</h3>
               </div>
            </div>

            <div className="space-y-4">
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
                <p className="text-slate-400 text-sm mb-2">{selectedNode.description}</p>
                <div className="flex justify-between items-center mt-3 pt-3 border-t border-slate-800">
                   <span className="text-sm text-slate-500">Nilai Tambah:</span>
                   <span className="text-lg font-bold text-green-400">{selectedNode.valueAdded}</span>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-white mb-2 flex items-center gap-2">
                   <Building2 size={14} className="text-slate-400" />
                   Perusahaan Kunci / Key Players
                </h4>
                <div className="flex flex-wrap gap-2">
                   {selectedNode.companies.map((company, idx) => (
                     <span key={idx} className="px-3 py-1 bg-slate-800 text-slate-300 text-xs rounded-full border border-slate-700">
                       {company}
                     </span>
                   ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const NodeCard: React.FC<{ node: ValueChainNode; onClick: () => void }> = ({ node, onClick }) => (
  <div 
    onClick={onClick}
    className="bg-slate-800 border border-slate-700 p-4 rounded-lg cursor-pointer hover:border-nusantara-500 hover:shadow-[0_0_15px_rgba(14,165,233,0.15)] transition-all group relative"
  >
    <div className="absolute top-0 right-0 px-2 py-1 bg-slate-950/50 rounded-bl-lg border-b border-l border-slate-700 text-[10px] text-green-400 font-bold">
      +{node.valueAdded}
    </div>
    <h4 className="font-bold text-white mb-1 group-hover:text-nusantara-400 transition-colors">{node.label}</h4>
    <p className="text-xs text-slate-400 line-clamp-2">{node.description}</p>
  </div>
);

export default ValueChainTree;