export interface ProductionData {
  year: number;
  rawExport: number; // In Million USD
  processedExport: number; // In Million USD
  smelterCount: number;
}

export enum CommodityType {
  NICKEL = 'Nickel',
  PALM_OIL = 'Palm Oil',
  BAUXITE = 'Bauxite',
  COPPER = 'Copper',
  COAL = 'Coal'
}

export interface HSCodeInfo {
  code: string;
  description: string;
  category: 'Raw' | 'Processed';
  tariff: number; // Export duty %
}

export interface SpotlightInfo {
  headline: string;
  subHeadline: string;
  metrics: {
    valueCreation: string;
    jobCreation: string;
    revenue: string;
  };
}

export interface Commodity {
  id: string;
  name: string;
  type: CommodityType;
  reserves: string;
  description: string;
  data: ProductionData[];
  regulations: string[];
  location: string[];
  hsCodes: HSCodeInfo[];
  spotlight?: SpotlightInfo; // Optional spotlight data for Hero section
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  isLoading?: boolean;
}

export interface KPIMetric {
  id: string; // Added ID for editing
  label: string;
  value: string;
  change: number; // Percentage
  trend: 'up' | 'down' | 'neutral';
}

export interface MarketShare {
  country: string;
  share: number;
  fill: string;
}

export interface PSNStatus {
  status: string;
  count: number;
  color: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'investor' | 'public';
}

// Value Chain Types
export interface ValueChainNode {
  id: string;
  label: string;
  category: 'Upstream' | 'Intermediate' | 'Downstream';
  description: string;
  valueAdded: string; // e.g., "1x"
  companies: string[];
  priceEstimate?: string; // New: For Industry Tree Gallery
}

export interface ValueChain {
  commodityId: string;
  nodes: ValueChainNode[];
  edges: { from: string; to: string }[];
}

// Comparison Slider Type
export interface ImpactComparison {
  commodity: string;
  before: {
    year: number;
    label: string;
    exportValue: string;
    jobs: string;
    description: string;
  };
  after: {
    year: number;
    label: string;
    exportValue: string;
    jobs: string;
    description: string;
  };
}

// GIS Map Types
export interface IndustrialZone {
  id: string;
  name: string;
  location: string;
  focus: CommodityType;
  coordinates: { x: number; y: number }; // Percentage 0-100
  status: 'Beroperasi' | 'Konstruksi' | 'Perencanaan';
  capacity: string;
  jobs: number;
}

// Calculator Logic Types
export interface ValueAddedRatio {
  commodityId: string;
  rawPrice: number; // USD per ton
  processedPrice: number; // USD per ton
  productName: string;
  jobMultiplier: number; // jobs per 1000 ton
  taxRate: number; // decimal
}

// Knowledge Hub Types
export interface PolicyLog {
  id: string;
  year: number;
  title: string;
  description: string;
  impact: string;
  category: 'Law' | 'Regulation' | 'Ban' | 'Incentive';
}

export interface LibraryResource {
  id: string;
  title: string;
  category: 'Report' | 'Regulation' | 'Whitepaper' | 'Guide';
  fileType: string;
  fileSize: string;
  date: string;
}

export interface GlossaryTerm {
  id: string;
  term: string;
  definition: string;
  category: string;
}