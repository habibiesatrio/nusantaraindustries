import React from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { GLOBAL_MARKET_SHARE, PSN_STATUS } from '../services/mockData';
import { ArrowUpRight, TrendingUp, DollarSign } from 'lucide-react';
import { KPIMetric } from '../types';

interface EconomicOverviewProps {
  metrics: KPIMetric[];
}

const EconomicOverview: React.FC<EconomicOverviewProps> = ({ metrics }) => {
  // Exchange rate assumption
  const USD_TO_IDR = 15650;
  
  // Try to find the surplus metric from props, fallback to static if not found/parseable
  const surplusMetric = metrics.find(m => m.label.includes('Ekspor'));
  const rawValue = surplusMetric ? parseFloat(surplusMetric.value.replace(/[^0-9.]/g, '')) : 34.2;
  const surplusIDR = (rawValue * USD_TO_IDR).toLocaleString('id-ID');

  return (
    <section className="bg-slate-950 py-12 border-t border-slate-900">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-2">
          <TrendingUp className="text-nusantara-500" />
          Dashboard Ekonomi Makro & Mikro
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* Widget 1: Trade Surplus (Derived from Metrics) */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 hover:border-slate-700 transition-colors">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-slate-400 font-medium">Nilai Ekspor Hilirisasi</h3>
              <div className="p-2 bg-green-500/10 rounded-lg">
                <DollarSign className="text-green-500 w-5 h-5" />
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-4xl font-bold text-white tracking-tight">{surplusMetric ? surplusMetric.value : '$34.2B'}</p>
              <p className="text-sm text-slate-500 font-mono">≈ Rp {surplusIDR} Triliun</p>
            </div>
            <div className="mt-4 flex items-center gap-2 text-sm text-green-400 bg-green-500/5 px-3 py-2 rounded border border-green-500/10">
              <ArrowUpRight size={16} />
              <span>Tertinggi dalam sejarah (Akumulatif)</span>
            </div>
          </div>

          {/* Widget 2: Strategic Projects (PSN) */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 hover:border-slate-700 transition-colors">
            <h3 className="text-slate-400 font-medium mb-4">Status Proyek Strategis Nasional (PSN)</h3>
            <div className="flex items-center gap-6">
              <div className="h-32 w-32 relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={PSN_STATUS}
                      innerRadius={40}
                      outerRadius={60}
                      paddingAngle={5}
                      dataKey="count"
                      stroke="none"
                    >
                      {PSN_STATUS.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px'}} itemStyle={{color: '#fff'}} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xl font-bold text-white">100%</span>
                </div>
              </div>
              <div className="flex-1 space-y-3">
                {PSN_STATUS.map((item, idx) => (
                   <div key={idx} className="flex justify-between items-center text-sm">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full" style={{backgroundColor: item.color}}></span>
                        <span className="text-slate-300">{item.status}</span>
                      </div>
                      <span className="font-semibold text-white">{item.count}%</span>
                   </div>
                ))}
              </div>
            </div>
          </div>

          {/* Widget 3: Market Share Chart */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 hover:border-slate-700 transition-colors">
            <h3 className="text-slate-400 font-medium mb-4">Pangsa Pasar Nikel Global (2023)</h3>
            <div className="h-40 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={GLOBAL_MARKET_SHARE} layout="vertical" barSize={20}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#334155" />
                  <XAxis type="number" hide />
                  <YAxis type="category" dataKey="country" width={90} tick={{fontSize: 11, fill: '#94a3b8'}} interval={0} />
                  <Tooltip 
                     cursor={{fill: 'transparent'}}
                     contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }}
                  />
                  <Bar dataKey="share" radius={[0, 4, 4, 0]}>
                    {GLOBAL_MARKET_SHARE.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 text-xs text-slate-500 text-center">
              Indonesia mendominasi >50% pasokan nikel dunia.
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default EconomicOverview;