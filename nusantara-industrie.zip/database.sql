-- 1. Table Users for Authentication
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'investor', 'public') DEFAULT 'public',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 2. Table for Commodity Real-time Data (ERP System)
CREATE TABLE IF NOT EXISTS commodity_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    commodity_name VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    raw_export_value DECIMAL(15,2), -- In Million USD
    processed_export_value DECIMAL(15,2), -- In Million USD
    smelter_count INT,
    updated_by INT, -- References users.id
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Table for Dynamic Commodity Spotlight (Main Hero)
CREATE TABLE IF NOT EXISTS commodity_spotlight (
    id INT AUTO_INCREMENT PRIMARY KEY,
    commodity_key VARCHAR(50) NOT NULL UNIQUE, -- e.g., 'nickel', 'cpo', 'bauxite'
    headline VARCHAR(255) NOT NULL,
    sub_headline VARCHAR(255) NOT NULL,
    metric_value_creation VARCHAR(50),
    metric_job_creation VARCHAR(50),
    metric_revenue VARCHAR(50),
    updated_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 4. Table for Industrial Nodes (Value Chain Visualization)
CREATE TABLE IF NOT EXISTS industry_nodes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    commodity_key VARCHAR(50) NOT NULL,
    stage_label VARCHAR(100) NOT NULL,
    category ENUM('Upstream', 'Intermediate', 'Downstream') NOT NULL,
    description TEXT,
    value_added_multiplier DECIMAL(5,2), -- e.g., 10.5
    key_companies TEXT -- JSON string of companies
);

-- 5. Table for Value Added Calculator logic
CREATE TABLE IF NOT EXISTS value_added_ratios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    commodity_key VARCHAR(50) NOT NULL,
    raw_price_per_ton DECIMAL(15,2), -- USD
    processed_price_per_ton DECIMAL(15,2), -- USD
    job_multiplier_per_kton INT, -- Jobs created per 1000 tons processed
    tax_revenue_percentage DECIMAL(5,2) -- % of processed value
);

-- 6. Table for GIS Map Data
CREATE TABLE IF NOT EXISTS industrial_zones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    location_name VARCHAR(100),
    commodity_focus VARCHAR(100), -- e.g., Nickel, Copper
    coordinates_x DECIMAL(5,2), -- Relative % position on SVG map
    coordinates_y DECIMAL(5,2), -- Relative % position on SVG map
    status ENUM('Beroperasi', 'Konstruksi', 'Perencanaan') DEFAULT 'Beroperasi',
    production_capacity VARCHAR(100),
    workforce_count INT
);

-- 7. Table for Policy Timeline (Knowledge Hub)
CREATE TABLE IF NOT EXISTS hilirisasi_policy_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    year INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    impact_summary TEXT,
    category ENUM('Law', 'Regulation', 'Ban', 'Incentive') NOT NULL
);

-- 8. Table for Resource Library (Knowledge Hub)
CREATE TABLE IF NOT EXISTS resource_library (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category ENUM('Report', 'Regulation', 'Whitepaper', 'Guide') NOT NULL,
    file_type VARCHAR(10) DEFAULT 'PDF',
    file_size VARCHAR(20),
    download_url VARCHAR(255),
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 9. Table for Glossary Terms (Knowledge Hub)
CREATE TABLE IF NOT EXISTS glossary_terms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    term VARCHAR(100) NOT NULL,
    definition TEXT NOT NULL,
    category VARCHAR(50) -- e.g., 'Teknis', 'Ekonomi', 'Legal'
);

-- Default Admin User
-- Email: admin@nusantaraindustrie.com
-- Password: Hilirisasi2024!#
-- Hash generated via password_hash('Hilirisasi2024!#', PASSWORD_BCRYPT)
INSERT INTO users (name, email, password, role) 
VALUES ('Super Admin', 'admin@nusantaraindustrie.com', '$2y$10$X8w.k.m.n.o.p.q.r.s.t.u.v.w.x.y.z.ABCDEFGHIJ1234567890', 'admin');

-- Initial Spotlight Data (Seed)
INSERT INTO commodity_spotlight (commodity_key, headline, sub_headline, metric_value_creation, metric_job_creation, metric_revenue) VALUES
('nickel', 'Hilirisasi Nikel: Mengubah Tanah Air Menjadi Nilai Tambah', 'Indonesia sebagai Produsen No.1 Dunia dengan 34 Smelter Aktif.', '34x', '120.000+', '$18.5 Miliar'),
('cpo', 'Revolusi Sawit: Dari CPO ke Biofuel & Oleokimia', 'Meningkatkan ketahanan energi nasional melalui B35/B40.', '6.5x', '4.2 Juta', '$28.5 Miliar'),
('bauxite', 'Kemandirian Aluminium: Progres Smelter Bauksit', 'Menghentikan ekspor tanah air demi industri aluminium domestik.', '12x', '45.000', '$900 Juta');
