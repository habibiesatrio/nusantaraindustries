<?php
session_start();
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

if (isset($_SESSION['user_id'])) {
    echo json_encode([
        "isAuthenticated" => true,
        "user" => [
            "id" => $_SESSION['user_id'],
            "name" => $_SESSION['user_name'],
            "email" => $_SESSION['user_email'],
            "role" => $_SESSION['user_role']
        ]
    ]);
} else {
    // Jika ada aksi logout
    if (isset($_GET['action']) && $_GET['action'] == 'logout') {
        session_unset();
        session_destroy();
        echo json_encode(["message" => "Logged out successfully"]);
    } else {
        http_response_code(401);
        echo json_encode(["isAuthenticated" => false]);
    }
}
?>