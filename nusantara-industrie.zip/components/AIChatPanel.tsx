import React, { useState, useRef, useEffect } from 'react';
import { generateIndustryInsight } from '../services/geminiService';
import { ChatMessage, Commodity } from '../types';
import { Send, Bot, User, Sparkles, AlertCircle } from 'lucide-react';

interface AIChatPanelProps {
  selectedCommodity: Commodity | null;
}

const AIChatPanel: React.FC<AIChatPanelProps> = ({ selectedCommodity }) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: 'Halo. Saya Nusantara AI, asisten intelijen industri Anda. Silakan tanyakan tentang tren hilirisasi, dampak regulasi, atau prediksi pasar komoditas.',
      timestamp: new Date()
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const contextId = selectedCommodity ? selectedCommodity.id : undefined;
      const responseText = await generateIndustryInsight(userMsg.text, contextId);

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: responseText,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: "Maaf, terjadi kesalahan koneksi jaringan atau API Key belum dikonfigurasi.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-800 rounded-xl border border-slate-700 overflow-hidden shadow-xl">
      <div className="p-4 bg-slate-900 border-b border-slate-700 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="text-nusantara-400 w-5 h-5" />
          <h2 className="text-white font-semibold">Nusantara Intelligence</h2>
        </div>
        {selectedCommodity && (
          <span className="text-xs bg-nusantara-900 text-nusantara-300 px-2 py-1 rounded border border-nusantara-700">
            Konteks: {selectedCommodity.name}
          </span>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex max-w-[85%] gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${msg.role === 'user' ? 'bg-slate-600' : 'bg-nusantara-600'}`}>
                {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
              </div>
              <div className={`p-3 rounded-lg text-sm leading-relaxed ${
                msg.role === 'user' 
                  ? 'bg-slate-700 text-white rounded-tr-none' 
                  : 'bg-slate-900/50 text-slate-200 border border-slate-700 rounded-tl-none'
              }`}>
                {msg.text.split('\n').map((line, i) => (
                  <p key={i} className={i > 0 ? 'mt-2' : ''}>{line}</p>
                ))}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="flex max-w-[85%] gap-3">
              <div className="w-8 h-8 rounded-full bg-nusantara-600 flex items-center justify-center flex-shrink-0">
                <Bot size={16} />
              </div>
              <div className="p-3 bg-slate-900/50 border border-slate-700 rounded-lg rounded-tl-none">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '0ms'}}></span>
                  <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '150ms'}}></span>
                  <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '300ms'}}></span>
                </div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-slate-900 border-t border-slate-700">
        <div className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Tanya tentang tren ekspor, prediksi, atau regulasi..."
            className="w-full bg-slate-800 text-white rounded-lg pl-4 pr-12 py-3 border border-slate-700 focus:border-nusantara-500 focus:ring-1 focus:ring-nusantara-500 outline-none transition-all placeholder:text-slate-500"
          />
          <button 
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="absolute right-2 top-2 p-1.5 bg-nusantara-600 text-white rounded-md hover:bg-nusantara-500 disabled:opacity-50 disabled:hover:bg-nusantara-600 transition-colors"
          >
            <Send size={18} />
          </button>
        </div>
        <div className="mt-2 flex items-center justify-center gap-1 text-[10px] text-slate-500">
           <AlertCircle size={10} />
           <span>Data di-generate oleh AI dan mungkin perlu verifikasi manual.</span>
        </div>
      </div>
    </div>
  );
};

export default AIChatPanel;