import React from 'react';
import { Commodity } from '../types';
import { ArrowUpRight, MapPin, Scale } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface CommodityCardProps {
  data: Commodity;
  onClick: () => void;
}

const CommodityCard: React.FC<CommodityCardProps> = ({ data, onClick }) => {
  const latestData = data.data[data.data.length - 1];
  const previousData = data.data[data.data.length - 2];
  
  const growth = ((latestData.processedExport - previousData.processedExport) / previousData.processedExport) * 100;

  return (
    <div 
      onClick={onClick}
      className="bg-slate-800 border border-slate-700 rounded-xl p-5 hover:border-nusantara-500/50 transition-all cursor-pointer group"
    >
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold text-white group-hover:text-nusantara-400 transition-colors">{data.name}</h3>
          <p className="text-sm text-slate-400 flex items-center gap-1 mt-1">
            <MapPin size={14} />
            {data.location[0]}
          </p>
        </div>
        <div className={`px-2 py-1 rounded text-xs font-bold ${growth >= 0 ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
          {growth > 0 ? '+' : ''}{growth.toFixed(1)}%
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-slate-900/50 p-3 rounded-lg">
          <p className="text-xs text-slate-500 mb-1">Ekspor Hilir (2023)</p>
          <p className="text-lg font-bold text-white">${(latestData.processedExport / 1000).toFixed(1)}B</p>
        </div>
        <div className="bg-slate-900/50 p-3 rounded-lg">
          <p className="text-xs text-slate-500 mb-1">Smelter Aktif</p>
          <p className="text-lg font-bold text-white">{latestData.smelterCount} Unit</p>
        </div>
      </div>

      <div className="h-24 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data.data}>
            <defs>
              <linearGradient id={`colorPv-${data.id}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" />
            <XAxis dataKey="year" hide />
            <YAxis hide />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#fff' }}
              itemStyle={{ color: '#bae6fd' }}
              labelStyle={{ color: '#94a3b8' }}
            />
            <Area 
              type="monotone" 
              dataKey="processedExport" 
              stroke="#0ea5e9" 
              fillOpacity={1} 
              fill={`url(#colorPv-${data.id})`} 
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      
      <div className="mt-4 flex items-center gap-2 text-xs text-slate-500">
        <Scale size={14} />
        <span>{data.regulations.length} Regulasi Aktif</span>
      </div>
    </div>
  );
};

export default CommodityCard;