import React, { useState } from 'react';
import { ImpactComparison } from '../types';
import { ArrowLeftRight, Briefcase, DollarSign } from 'lucide-react';

interface ComparisonSliderProps {
  data: ImpactComparison[];
}

const ComparisonSlider: React.FC<ComparisonSliderProps> = ({ data }) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [selectedCommodity, setSelectedCommodity] = useState(data[0].commodity);

  const currentData = data.find(d => d.commodity === selectedCommodity) || data[0];

  const handleDrag = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSliderPosition(parseInt(e.target.value));
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden mb-8">
      <div className="p-6 border-b border-slate-800 flex justify-between items-center">
        <div>
           <h3 className="text-xl font-bold text-white flex items-center gap-2">
             <ArrowLeftRight className="text-nusantara-500" />
             Dampak Ekonomi: Raw vs Processed
           </h3>
           <p className="text-sm text-slate-400">Geser slider untuk melihat transformasi ekonomi sebelum dan sesudah hilirisasi.</p>
        </div>
        <select 
          value={selectedCommodity}
          onChange={(e) => setSelectedCommodity(e.target.value)}
          className="bg-slate-950 border border-slate-700 text-white px-4 py-2 rounded-lg text-sm outline-none focus:border-nusantara-500"
        >
          <option value="nickel-01">Nikel</option>
          <option value="cpo-01">Kelapa Sawit</option>
        </select>
      </div>

      <div className="relative w-full h-[400px] select-none overflow-hidden group">
        
        {/* Layer 1: BEFORE (Background) - Raw Era */}
        <div className="absolute inset-0 bg-slate-800 flex items-center justify-center">
           <div className="container max-w-4xl mx-auto grid grid-cols-2 px-8">
              <div className="bg-slate-900/80 p-8 rounded-xl border border-slate-700 backdrop-blur-sm">
                 <div className="mb-4 inline-block px-3 py-1 bg-red-500/10 text-red-400 text-xs font-bold rounded uppercase border border-red-500/20">
                   Masa Lalu ({currentData.before.year})
                 </div>
                 <h2 className="text-3xl font-bold text-slate-400 mb-2">{currentData.before.label}</h2>
                 <p className="text-slate-500 mb-6">{currentData.before.description}</p>
                 
                 <div className="space-y-4 opacity-70 grayscale">
                    <div className="flex items-center gap-4">
                       <div className="p-3 bg-slate-800 rounded-lg"><DollarSign className="text-slate-400" /></div>
                       <div>
                          <p className="text-sm text-slate-500">Nilai Ekspor</p>
                          <p className="text-2xl font-bold text-white">{currentData.before.exportValue}</p>
                       </div>
                    </div>
                    <div className="flex items-center gap-4">
                       <div className="p-3 bg-slate-800 rounded-lg"><Briefcase className="text-slate-400" /></div>
                       <div>
                          <p className="text-sm text-slate-500">Lapangan Kerja</p>
                          <p className="text-2xl font-bold text-white">{currentData.before.jobs}</p>
                       </div>
                    </div>
                 </div>
              </div>
              <div></div> {/* Empty right column for layout balance */}
           </div>
        </div>

        {/* Layer 2: AFTER (Foreground) - Downstream Era - Clipped */}
        <div 
          className="absolute inset-0 bg-gradient-to-br from-nusantara-900 to-slate-900 flex items-center justify-center"
          style={{ clipPath: `inset(0 0 0 ${sliderPosition}%)` }}
        >
           {/* Decorative Background */}
           <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1565514020125-6c70505df84b?q=80&w=2000&auto=format&fit=crop')] opacity-10 bg-cover bg-center mix-blend-overlay"></div>

           <div className="container max-w-4xl mx-auto grid grid-cols-2 px-8 relative z-10">
              <div></div> {/* Empty left column */}
              <div className="bg-slate-900/90 p-8 rounded-xl border border-nusantara-500/50 backdrop-blur-md shadow-2xl">
                 <div className="mb-4 inline-block px-3 py-1 bg-green-500/10 text-green-400 text-xs font-bold rounded uppercase border border-green-500/20">
                   Masa Kini ({currentData.after.year})
                 </div>
                 <h2 className="text-3xl font-bold text-white mb-2">{currentData.after.label}</h2>
                 <p className="text-nusantara-200 mb-6">{currentData.after.description}</p>
                 
                 <div className="space-y-4">
                    <div className="flex items-center gap-4">
                       <div className="p-3 bg-nusantara-600 rounded-lg shadow-lg shadow-nusantara-600/20"><DollarSign className="text-white" /></div>
                       <div>
                          <p className="text-sm text-nusantara-200">Nilai Ekspor</p>
                          <p className="text-3xl font-bold text-white tracking-tight">{currentData.after.exportValue}</p>
                       </div>
                    </div>
                    <div className="flex items-center gap-4">
                       <div className="p-3 bg-green-600 rounded-lg shadow-lg shadow-green-600/20"><Briefcase className="text-white" /></div>
                       <div>
                          <p className="text-sm text-nusantara-200">Lapangan Kerja</p>
                          <p className="text-3xl font-bold text-white tracking-tight">{currentData.after.jobs}</p>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>

        {/* Slider Handle */}
        <input
          type="range"
          min="0"
          max="100"
          value={sliderPosition}
          onChange={handleDrag}
          className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-30"
        />
        
        {/* Visual Line and Handle */}
        <div 
          className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-20 shadow-[0_0_15px_rgba(255,255,255,0.5)] pointer-events-none"
          style={{ left: `${sliderPosition}%` }}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-xl">
            <ArrowLeftRight size={16} className="text-slate-900" />
          </div>
        </div>

        {/* Labels */}
        <div className="absolute bottom-4 left-8 text-xs text-slate-500 font-bold tracking-widest uppercase z-20 pointer-events-none">
            &larr; Era Bahan Mentah
        </div>
        <div className="absolute bottom-4 right-8 text-xs text-nusantara-400 font-bold tracking-widest uppercase z-20 pointer-events-none">
            Era Hilirisasi &rarr;
        </div>

      </div>
    </div>
  );
};

export default ComparisonSlider;